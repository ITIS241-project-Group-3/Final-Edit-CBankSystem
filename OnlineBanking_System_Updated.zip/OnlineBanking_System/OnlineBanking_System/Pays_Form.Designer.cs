﻿
namespace OnlineBanking_System
{
    partial class Pays_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            Guna.UI2.AnimatorNS.Animation animation1 = new Guna.UI2.AnimatorNS.Animation();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Pays_Form));
            this.CustomBorder = new Guna.UI2.WinForms.Guna2BorderlessForm(this.components);
            this.MainPanel = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Separator1 = new Guna.UI2.WinForms.Guna2Separator();
            this.label1 = new System.Windows.Forms.Label();
            this.Return_btn = new Guna.UI2.WinForms.Guna2PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Networks_btn = new Guna.UI2.WinForms.Guna2Button();
            this.guna2VSeparator1 = new Guna.UI2.WinForms.Guna2VSeparator();
            this.University_btn = new Guna.UI2.WinForms.Guna2Button();
            this.Seprator1 = new Guna.UI2.WinForms.Guna2VSeparator();
            this.Market_btn = new Guna.UI2.WinForms.Guna2Button();
            this.Markets_panel = new Guna.UI2.WinForms.Guna2Panel();
            this.MainNetworkPanel = new Guna.UI2.WinForms.Guna2Panel();
            this.NetworkDatagridPanel = new Guna.UI2.WinForms.Guna2Panel();
            this.Net_BackBtn = new Guna.UI2.WinForms.Guna2PictureBox();
            this.Net_SaveBtn = new Guna.UI2.WinForms.Guna2Button();
            this.Net_Upbtn = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.net_DownBtn = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.NetworkDatagrid = new Guna.UI2.WinForms.Guna2DataGridView();
            this.idDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.shopNameDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.invoiceNoDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.commentDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.userNameDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.paysBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.onlineBankingSystemDBDataset1 = new OnlineBanking_System.OnlineBankingSystemDBDataset();
            this.guna2CirclePictureBox1 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.Net_InvoiceTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            this.Net_CommentTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            this.Net_AmountTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            this.Net_HistoryBtn = new Guna.UI2.WinForms.Guna2Button();
            this.Net_ClearBtn = new Guna.UI2.WinForms.Guna2Button();
            this.Net_PayBtn = new Guna.UI2.WinForms.Guna2Button();
            this.Net_Combobox = new Guna.UI2.WinForms.Guna2ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.MainUniversityPanel = new Guna.UI2.WinForms.Guna2Panel();
            this.UniversityDatagridViewPanel = new Guna.UI2.WinForms.Guna2Panel();
            this.UniversityBackBtn = new Guna.UI2.WinForms.Guna2PictureBox();
            this.University_SaveBtn = new Guna.UI2.WinForms.Guna2Button();
            this.Unversity_UpBtn = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.University_DownBtn = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.UniversityDatagridview = new Guna.UI2.WinForms.Guna2DataGridView();
            this.idDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.shopNameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.invoiceNoDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.commentDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.userNameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UniversityInvoice_textbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.UniversityComment_TextBox = new Guna.UI2.WinForms.Guna2TextBox();
            this.University_AmountTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            this.University_historyBtn = new Guna.UI2.WinForms.Guna2Button();
            this.University_ClearBtn = new Guna.UI2.WinForms.Guna2Button();
            this.University_PayBtn = new Guna.UI2.WinForms.Guna2Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.UniversityName_Combobox = new Guna.UI2.WinForms.Guna2ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.MainMarketPanel = new Guna.UI2.WinForms.Guna2Panel();
            this.Market_panel = new Guna.UI2.WinForms.Guna2Panel();
            this.Market_History_btn = new Guna.UI2.WinForms.Guna2Button();
            this.Clear_btn = new Guna.UI2.WinForms.Guna2Button();
            this.Pay_btn = new Guna.UI2.WinForms.Guna2Button();
            this.Invoice_textBox = new Guna.UI2.WinForms.Guna2TextBox();
            this.Comment_textBoxx = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Amount_textBox = new Guna.UI2.WinForms.Guna2TextBox();
            this.Markets_combbox = new Guna.UI2.WinForms.Guna2ComboBox();
            this.Markets_DataGrid_panel = new Guna.UI2.WinForms.Guna2Panel();
            this.Back_TOPanelBTN = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.Down_btn = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.Up_btn = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.save_btn = new Guna.UI2.WinForms.Guna2Button();
            this.Market_Datagridview = new Guna.UI2.WinForms.Guna2DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.shopNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.invoiceNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.commentDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.userNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Comment_textBox = new Guna.UI2.WinForms.Guna2TextBox();
            this.one_m = new Guna.UI2.WinForms.Guna2Panel();
            this.DateTime_label = new System.Windows.Forms.Label();
            this.guna2Separator2 = new Guna.UI2.WinForms.Guna2Separator();
            this.Show_Balance_btn = new Guna.UI2.WinForms.Guna2Button();
            this.AccountName_label = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Transition = new Guna.UI2.WinForms.Guna2Transition();
            this.DragControl1 = new Guna.UI2.WinForms.Guna2DragControl(this.components);
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.paysTableAdapter = new OnlineBanking_System.OnlineBankingSystemDBDatasetTableAdapters.PaysTableAdapter();
            this.MainPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Return_btn)).BeginInit();
            this.panel1.SuspendLayout();
            this.Markets_panel.SuspendLayout();
            this.MainNetworkPanel.SuspendLayout();
            this.NetworkDatagridPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Net_BackBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Net_Upbtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.net_DownBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NetworkDatagrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.paysBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.onlineBankingSystemDBDataset1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox1)).BeginInit();
            this.MainUniversityPanel.SuspendLayout();
            this.UniversityDatagridViewPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.UniversityBackBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Unversity_UpBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.University_DownBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.UniversityDatagridview)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.MainMarketPanel.SuspendLayout();
            this.Market_panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            this.Markets_DataGrid_panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Back_TOPanelBTN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Down_btn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Up_btn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Market_Datagridview)).BeginInit();
            this.one_m.SuspendLayout();
            this.SuspendLayout();
            // 
            // CustomBorder
            // 
            this.CustomBorder.AnimateWindow = true;
            this.CustomBorder.BorderRadius = 50;
            this.CustomBorder.ContainerControl = this;
            this.CustomBorder.ShadowColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.CustomBorder.TransparentWhileDrag = true;
            // 
            // MainPanel
            // 
            this.MainPanel.Controls.Add(this.guna2Separator1);
            this.MainPanel.Controls.Add(this.label1);
            this.MainPanel.Controls.Add(this.Return_btn);
            this.Transition.SetDecoration(this.MainPanel, Guna.UI2.AnimatorNS.DecorationType.None);
            this.MainPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.MainPanel.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.MainPanel.Location = new System.Drawing.Point(0, 0);
            this.MainPanel.Name = "MainPanel";
            this.MainPanel.ShadowDecoration.Parent = this.MainPanel;
            this.MainPanel.Size = new System.Drawing.Size(1216, 99);
            this.MainPanel.TabIndex = 0;
            // 
            // guna2Separator1
            // 
            this.guna2Separator1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.Transition.SetDecoration(this.guna2Separator1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2Separator1.FillColor = System.Drawing.Color.White;
            this.guna2Separator1.FillThickness = 3;
            this.guna2Separator1.Location = new System.Drawing.Point(0, 89);
            this.guna2Separator1.Name = "guna2Separator1";
            this.guna2Separator1.Size = new System.Drawing.Size(1216, 16);
            this.guna2Separator1.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.Transition.SetDecoration(this.label1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.label1.Font = new System.Drawing.Font("Palatino Linotype", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(410, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(402, 56);
            this.label1.TabIndex = 1;
            this.label1.Text = "Pays Bills";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Return_btn
            // 
            this.Return_btn.BackColor = System.Drawing.Color.Transparent;
            this.Return_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Transition.SetDecoration(this.Return_btn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Return_btn.Image = global::OnlineBanking_System.Properties.Resources.back;
            this.Return_btn.Location = new System.Drawing.Point(12, 22);
            this.Return_btn.Name = "Return_btn";
            this.Return_btn.ShadowDecoration.Parent = this.Return_btn;
            this.Return_btn.Size = new System.Drawing.Size(53, 53);
            this.Return_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Return_btn.TabIndex = 0;
            this.Return_btn.TabStop = false;
            this.toolTip1.SetToolTip(this.Return_btn, "Return to Main Form");
            this.Return_btn.UseTransparentBackground = true;
            this.Return_btn.Click += new System.EventHandler(this.Return_btn_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.panel1.Controls.Add(this.Networks_btn);
            this.panel1.Controls.Add(this.guna2VSeparator1);
            this.panel1.Controls.Add(this.University_btn);
            this.panel1.Controls.Add(this.Seprator1);
            this.panel1.Controls.Add(this.Market_btn);
            this.Transition.SetDecoration(this.panel1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 99);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1216, 92);
            this.panel1.TabIndex = 1;
            // 
            // Networks_btn
            // 
            this.Networks_btn.Animated = true;
            this.Networks_btn.BackColor = System.Drawing.Color.Transparent;
            this.Networks_btn.CheckedState.Parent = this.Networks_btn;
            this.Networks_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Networks_btn.CustomImages.Parent = this.Networks_btn;
            this.Transition.SetDecoration(this.Networks_btn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Networks_btn.Dock = System.Windows.Forms.DockStyle.Left;
            this.Networks_btn.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.Networks_btn.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.Networks_btn.ForeColor = System.Drawing.Color.White;
            this.Networks_btn.HoverState.Parent = this.Networks_btn;
            this.Networks_btn.Image = global::OnlineBanking_System.Properties.Resources.wifi;
            this.Networks_btn.ImageSize = new System.Drawing.Size(50, 50);
            this.Networks_btn.Location = new System.Drawing.Point(841, 0);
            this.Networks_btn.Name = "Networks_btn";
            this.Networks_btn.ShadowDecoration.Parent = this.Networks_btn;
            this.Networks_btn.Size = new System.Drawing.Size(373, 92);
            this.Networks_btn.TabIndex = 6;
            this.Networks_btn.Text = "Networks";
            this.Networks_btn.TextOffset = new System.Drawing.Point(3, 0);
            this.toolTip1.SetToolTip(this.Networks_btn, "Pay Networks bills");
            this.Networks_btn.UseTransparentBackground = true;
            this.Networks_btn.Click += new System.EventHandler(this.Networks_btn_Click);
            // 
            // guna2VSeparator1
            // 
            this.Transition.SetDecoration(this.guna2VSeparator1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2VSeparator1.Dock = System.Windows.Forms.DockStyle.Left;
            this.guna2VSeparator1.FillColor = System.Drawing.Color.White;
            this.guna2VSeparator1.FillThickness = 3;
            this.guna2VSeparator1.Location = new System.Drawing.Point(831, 0);
            this.guna2VSeparator1.Name = "guna2VSeparator1";
            this.guna2VSeparator1.Size = new System.Drawing.Size(10, 92);
            this.guna2VSeparator1.TabIndex = 5;
            // 
            // University_btn
            // 
            this.University_btn.Animated = true;
            this.University_btn.BackColor = System.Drawing.Color.Transparent;
            this.University_btn.CheckedState.Parent = this.University_btn;
            this.University_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.University_btn.CustomImages.Parent = this.University_btn;
            this.Transition.SetDecoration(this.University_btn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.University_btn.Dock = System.Windows.Forms.DockStyle.Left;
            this.University_btn.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.University_btn.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.University_btn.ForeColor = System.Drawing.Color.White;
            this.University_btn.HoverState.Parent = this.University_btn;
            this.University_btn.Image = global::OnlineBanking_System.Properties.Resources.school;
            this.University_btn.ImageSize = new System.Drawing.Size(50, 50);
            this.University_btn.Location = new System.Drawing.Point(409, 0);
            this.University_btn.Name = "University_btn";
            this.University_btn.ShadowDecoration.Parent = this.University_btn;
            this.University_btn.Size = new System.Drawing.Size(422, 92);
            this.University_btn.TabIndex = 4;
            this.University_btn.Text = "University";
            this.University_btn.TextOffset = new System.Drawing.Point(3, 0);
            this.toolTip1.SetToolTip(this.University_btn, "Pay university bills");
            this.University_btn.UseTransparentBackground = true;
            this.University_btn.Click += new System.EventHandler(this.University_btn_Click);
            // 
            // Seprator1
            // 
            this.Transition.SetDecoration(this.Seprator1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Seprator1.Dock = System.Windows.Forms.DockStyle.Left;
            this.Seprator1.FillColor = System.Drawing.Color.White;
            this.Seprator1.FillThickness = 3;
            this.Seprator1.Location = new System.Drawing.Point(399, 0);
            this.Seprator1.Name = "Seprator1";
            this.Seprator1.Size = new System.Drawing.Size(10, 92);
            this.Seprator1.TabIndex = 1;
            // 
            // Market_btn
            // 
            this.Market_btn.Animated = true;
            this.Market_btn.BackColor = System.Drawing.Color.Transparent;
            this.Market_btn.CheckedState.Parent = this.Market_btn;
            this.Market_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Market_btn.CustomImages.Parent = this.Market_btn;
            this.Transition.SetDecoration(this.Market_btn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Market_btn.Dock = System.Windows.Forms.DockStyle.Left;
            this.Market_btn.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.Market_btn.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.Market_btn.ForeColor = System.Drawing.Color.White;
            this.Market_btn.HoverState.Parent = this.Market_btn;
            this.Market_btn.Image = global::OnlineBanking_System.Properties.Resources.shopping_cart;
            this.Market_btn.ImageSize = new System.Drawing.Size(50, 50);
            this.Market_btn.Location = new System.Drawing.Point(0, 0);
            this.Market_btn.Name = "Market_btn";
            this.Market_btn.ShadowDecoration.Parent = this.Market_btn;
            this.Market_btn.Size = new System.Drawing.Size(399, 92);
            this.Market_btn.TabIndex = 0;
            this.Market_btn.Text = "Markets";
            this.Market_btn.TextOffset = new System.Drawing.Point(3, 0);
            this.toolTip1.SetToolTip(this.Market_btn, "Pay Markets bill");
            this.Market_btn.UseTransparentBackground = true;
            this.Market_btn.Click += new System.EventHandler(this.Market_btn_Click);
            // 
            // Markets_panel
            // 
            this.Markets_panel.BackColor = System.Drawing.Color.White;
            this.Markets_panel.Controls.Add(this.MainNetworkPanel);
            this.Markets_panel.Controls.Add(this.MainUniversityPanel);
            this.Markets_panel.Controls.Add(this.MainMarketPanel);
            this.Markets_panel.Controls.Add(this.Comment_textBox);
            this.Markets_panel.Controls.Add(this.one_m);
            this.Transition.SetDecoration(this.Markets_panel, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Markets_panel.Dock = System.Windows.Forms.DockStyle.Top;
            this.Markets_panel.Location = new System.Drawing.Point(0, 191);
            this.Markets_panel.Name = "Markets_panel";
            this.Markets_panel.ShadowDecoration.Parent = this.Markets_panel;
            this.Markets_panel.Size = new System.Drawing.Size(1216, 617);
            this.Markets_panel.TabIndex = 2;
            this.Markets_panel.Visible = false;
            // 
            // MainNetworkPanel
            // 
            this.MainNetworkPanel.BackColor = System.Drawing.Color.White;
            this.MainNetworkPanel.Controls.Add(this.NetworkDatagridPanel);
            this.MainNetworkPanel.Controls.Add(this.guna2CirclePictureBox1);
            this.MainNetworkPanel.Controls.Add(this.Net_InvoiceTextBox);
            this.MainNetworkPanel.Controls.Add(this.Net_CommentTextBox);
            this.MainNetworkPanel.Controls.Add(this.Net_AmountTextBox);
            this.MainNetworkPanel.Controls.Add(this.Net_HistoryBtn);
            this.MainNetworkPanel.Controls.Add(this.Net_ClearBtn);
            this.MainNetworkPanel.Controls.Add(this.Net_PayBtn);
            this.MainNetworkPanel.Controls.Add(this.Net_Combobox);
            this.MainNetworkPanel.Controls.Add(this.label5);
            this.Transition.SetDecoration(this.MainNetworkPanel, Guna.UI2.AnimatorNS.DecorationType.None);
            this.MainNetworkPanel.Location = new System.Drawing.Point(3, 155);
            this.MainNetworkPanel.Name = "MainNetworkPanel";
            this.MainNetworkPanel.ShadowDecoration.Parent = this.MainNetworkPanel;
            this.MainNetworkPanel.Size = new System.Drawing.Size(1210, 459);
            this.MainNetworkPanel.TabIndex = 5;
            this.MainNetworkPanel.Visible = false;
            // 
            // NetworkDatagridPanel
            // 
            this.NetworkDatagridPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.NetworkDatagridPanel.Controls.Add(this.Net_BackBtn);
            this.NetworkDatagridPanel.Controls.Add(this.Net_SaveBtn);
            this.NetworkDatagridPanel.Controls.Add(this.Net_Upbtn);
            this.NetworkDatagridPanel.Controls.Add(this.net_DownBtn);
            this.NetworkDatagridPanel.Controls.Add(this.NetworkDatagrid);
            this.Transition.SetDecoration(this.NetworkDatagridPanel, Guna.UI2.AnimatorNS.DecorationType.None);
            this.NetworkDatagridPanel.Location = new System.Drawing.Point(9, 0);
            this.NetworkDatagridPanel.Name = "NetworkDatagridPanel";
            this.NetworkDatagridPanel.ShadowDecoration.Parent = this.NetworkDatagridPanel;
            this.NetworkDatagridPanel.Size = new System.Drawing.Size(1192, 453);
            this.NetworkDatagridPanel.TabIndex = 26;
            this.NetworkDatagridPanel.Visible = false;
            // 
            // Net_BackBtn
            // 
            this.Net_BackBtn.BackColor = System.Drawing.Color.Transparent;
            this.Net_BackBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Transition.SetDecoration(this.Net_BackBtn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Net_BackBtn.Image = global::OnlineBanking_System.Properties.Resources.back;
            this.Net_BackBtn.Location = new System.Drawing.Point(1129, 15);
            this.Net_BackBtn.Name = "Net_BackBtn";
            this.Net_BackBtn.ShadowDecoration.Parent = this.Net_BackBtn;
            this.Net_BackBtn.Size = new System.Drawing.Size(48, 48);
            this.Net_BackBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Net_BackBtn.TabIndex = 8;
            this.Net_BackBtn.TabStop = false;
            this.toolTip1.SetToolTip(this.Net_BackBtn, "Return to Network section");
            this.Net_BackBtn.UseTransparentBackground = true;
            this.Net_BackBtn.Click += new System.EventHandler(this.Net_BackBtn_Click);
            // 
            // Net_SaveBtn
            // 
            this.Net_SaveBtn.Animated = true;
            this.Net_SaveBtn.AutoRoundedCorners = true;
            this.Net_SaveBtn.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.Net_SaveBtn.BorderRadius = 22;
            this.Net_SaveBtn.BorderThickness = 2;
            this.Net_SaveBtn.CheckedState.Parent = this.Net_SaveBtn;
            this.Net_SaveBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Net_SaveBtn.CustomImages.Parent = this.Net_SaveBtn;
            this.Transition.SetDecoration(this.Net_SaveBtn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Net_SaveBtn.FillColor = System.Drawing.Color.White;
            this.Net_SaveBtn.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Net_SaveBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.Net_SaveBtn.HoverState.BorderColor = System.Drawing.Color.White;
            this.Net_SaveBtn.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.Net_SaveBtn.HoverState.ForeColor = System.Drawing.Color.White;
            this.Net_SaveBtn.HoverState.Parent = this.Net_SaveBtn;
            this.Net_SaveBtn.Location = new System.Drawing.Point(979, 202);
            this.Net_SaveBtn.Name = "Net_SaveBtn";
            this.Net_SaveBtn.ShadowDecoration.Parent = this.Net_SaveBtn;
            this.Net_SaveBtn.Size = new System.Drawing.Size(133, 46);
            this.Net_SaveBtn.TabIndex = 7;
            this.Net_SaveBtn.Text = "Save";
            this.toolTip1.SetToolTip(this.Net_SaveBtn, "Save information");
            this.Net_SaveBtn.Click += new System.EventHandler(this.Net_SaveBtn_Click);
            // 
            // Net_Upbtn
            // 
            this.Net_Upbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Transition.SetDecoration(this.Net_Upbtn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Net_Upbtn.Image = global::OnlineBanking_System.Properties.Resources.down_chevron;
            this.Net_Upbtn.ImageFlip = Guna.UI2.WinForms.Enums.FlipOrientation.Vertical;
            this.Net_Upbtn.Location = new System.Drawing.Point(1011, 60);
            this.Net_Upbtn.Name = "Net_Upbtn";
            this.Net_Upbtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.Net_Upbtn.ShadowDecoration.Parent = this.Net_Upbtn;
            this.Net_Upbtn.Size = new System.Drawing.Size(62, 69);
            this.Net_Upbtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Net_Upbtn.TabIndex = 6;
            this.Net_Upbtn.TabStop = false;
            this.toolTip1.SetToolTip(this.Net_Upbtn, "Up");
            this.Net_Upbtn.UseTransparentBackground = true;
            this.Net_Upbtn.Click += new System.EventHandler(this.Net_Upbtn_Click);
            // 
            // net_DownBtn
            // 
            this.net_DownBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Transition.SetDecoration(this.net_DownBtn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.net_DownBtn.Image = global::OnlineBanking_System.Properties.Resources.down_chevron;
            this.net_DownBtn.Location = new System.Drawing.Point(1011, 315);
            this.net_DownBtn.Name = "net_DownBtn";
            this.net_DownBtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.net_DownBtn.ShadowDecoration.Parent = this.net_DownBtn;
            this.net_DownBtn.Size = new System.Drawing.Size(62, 69);
            this.net_DownBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.net_DownBtn.TabIndex = 5;
            this.net_DownBtn.TabStop = false;
            this.toolTip1.SetToolTip(this.net_DownBtn, "Down");
            this.net_DownBtn.UseTransparentBackground = true;
            this.net_DownBtn.Click += new System.EventHandler(this.net_DownBtn_Click);
            // 
            // NetworkDatagrid
            // 
            this.NetworkDatagrid.AllowUserToAddRows = false;
            this.NetworkDatagrid.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.NetworkDatagrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.NetworkDatagrid.AutoGenerateColumns = false;
            this.NetworkDatagrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.NetworkDatagrid.BackgroundColor = System.Drawing.Color.White;
            this.NetworkDatagrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.NetworkDatagrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.NetworkDatagrid.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.NetworkDatagrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.NetworkDatagrid.ColumnHeadersHeight = 21;
            this.NetworkDatagrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn2,
            this.shopNameDataGridViewTextBoxColumn2,
            this.invoiceNoDataGridViewTextBoxColumn2,
            this.commentDataGridViewTextBoxColumn2,
            this.userNameDataGridViewTextBoxColumn2});
            this.NetworkDatagrid.DataSource = this.paysBindingSource;
            this.Transition.SetDecoration(this.NetworkDatagrid, Guna.UI2.AnimatorNS.DecorationType.None);
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.NetworkDatagrid.DefaultCellStyle = dataGridViewCellStyle3;
            this.NetworkDatagrid.Dock = System.Windows.Forms.DockStyle.Left;
            this.NetworkDatagrid.EnableHeadersVisualStyles = false;
            this.NetworkDatagrid.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.NetworkDatagrid.Location = new System.Drawing.Point(0, 0);
            this.NetworkDatagrid.Name = "NetworkDatagrid";
            this.NetworkDatagrid.ReadOnly = true;
            this.NetworkDatagrid.RowHeadersVisible = false;
            this.NetworkDatagrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.NetworkDatagrid.Size = new System.Drawing.Size(912, 453);
            this.NetworkDatagrid.TabIndex = 0;
            this.NetworkDatagrid.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.Default;
            this.NetworkDatagrid.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.NetworkDatagrid.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.NetworkDatagrid.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.NetworkDatagrid.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.NetworkDatagrid.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.NetworkDatagrid.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.NetworkDatagrid.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.NetworkDatagrid.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.NetworkDatagrid.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.NetworkDatagrid.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.NetworkDatagrid.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.NetworkDatagrid.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.NetworkDatagrid.ThemeStyle.HeaderStyle.Height = 21;
            this.NetworkDatagrid.ThemeStyle.ReadOnly = true;
            this.NetworkDatagrid.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.NetworkDatagrid.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.NetworkDatagrid.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.NetworkDatagrid.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.NetworkDatagrid.ThemeStyle.RowsStyle.Height = 22;
            this.NetworkDatagrid.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.NetworkDatagrid.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            // 
            // idDataGridViewTextBoxColumn2
            // 
            this.idDataGridViewTextBoxColumn2.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn2.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn2.Name = "idDataGridViewTextBoxColumn2";
            this.idDataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // shopNameDataGridViewTextBoxColumn2
            // 
            this.shopNameDataGridViewTextBoxColumn2.DataPropertyName = "Shop Name ";
            this.shopNameDataGridViewTextBoxColumn2.HeaderText = "Shop Name ";
            this.shopNameDataGridViewTextBoxColumn2.Name = "shopNameDataGridViewTextBoxColumn2";
            this.shopNameDataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // invoiceNoDataGridViewTextBoxColumn2
            // 
            this.invoiceNoDataGridViewTextBoxColumn2.DataPropertyName = "Invoice No";
            this.invoiceNoDataGridViewTextBoxColumn2.HeaderText = "Invoice No";
            this.invoiceNoDataGridViewTextBoxColumn2.Name = "invoiceNoDataGridViewTextBoxColumn2";
            this.invoiceNoDataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // commentDataGridViewTextBoxColumn2
            // 
            this.commentDataGridViewTextBoxColumn2.DataPropertyName = "Comment";
            this.commentDataGridViewTextBoxColumn2.HeaderText = "Comment";
            this.commentDataGridViewTextBoxColumn2.Name = "commentDataGridViewTextBoxColumn2";
            this.commentDataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // userNameDataGridViewTextBoxColumn2
            // 
            this.userNameDataGridViewTextBoxColumn2.DataPropertyName = "User_Name";
            this.userNameDataGridViewTextBoxColumn2.HeaderText = "User_Name";
            this.userNameDataGridViewTextBoxColumn2.Name = "userNameDataGridViewTextBoxColumn2";
            this.userNameDataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // paysBindingSource
            // 
            this.paysBindingSource.DataMember = "Pays";
            this.paysBindingSource.DataSource = this.onlineBankingSystemDBDataset1;
            // 
            // onlineBankingSystemDBDataset1
            // 
            this.onlineBankingSystemDBDataset1.DataSetName = "OnlineBankingSystemDBDataset";
            this.onlineBankingSystemDBDataset1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // guna2CirclePictureBox1
            // 
            this.Transition.SetDecoration(this.guna2CirclePictureBox1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2CirclePictureBox1.Image = global::OnlineBanking_System.Properties.Resources.internet;
            this.guna2CirclePictureBox1.Location = new System.Drawing.Point(973, 96);
            this.guna2CirclePictureBox1.Name = "guna2CirclePictureBox1";
            this.guna2CirclePictureBox1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CirclePictureBox1.ShadowDecoration.Parent = this.guna2CirclePictureBox1;
            this.guna2CirclePictureBox1.Size = new System.Drawing.Size(200, 200);
            this.guna2CirclePictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2CirclePictureBox1.TabIndex = 25;
            this.guna2CirclePictureBox1.TabStop = false;
            this.guna2CirclePictureBox1.UseTransparentBackground = true;
            // 
            // Net_InvoiceTextBox
            // 
            this.Net_InvoiceTextBox.Animated = true;
            this.Net_InvoiceTextBox.AutoRoundedCorners = true;
            this.Net_InvoiceTextBox.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.Net_InvoiceTextBox.BorderRadius = 17;
            this.Net_InvoiceTextBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Transition.SetDecoration(this.Net_InvoiceTextBox, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Net_InvoiceTextBox.DefaultText = "";
            this.Net_InvoiceTextBox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Net_InvoiceTextBox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Net_InvoiceTextBox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Net_InvoiceTextBox.DisabledState.Parent = this.Net_InvoiceTextBox;
            this.Net_InvoiceTextBox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Net_InvoiceTextBox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Net_InvoiceTextBox.FocusedState.Parent = this.Net_InvoiceTextBox;
            this.Net_InvoiceTextBox.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.Net_InvoiceTextBox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Net_InvoiceTextBox.HoverState.Parent = this.Net_InvoiceTextBox;
            this.Net_InvoiceTextBox.IconLeft = global::OnlineBanking_System.Properties.Resources.financial;
            this.Net_InvoiceTextBox.Location = new System.Drawing.Point(323, 137);
            this.Net_InvoiceTextBox.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.Net_InvoiceTextBox.Name = "Net_InvoiceTextBox";
            this.Net_InvoiceTextBox.PasswordChar = '\0';
            this.Net_InvoiceTextBox.PlaceholderText = "Enter the invoice No";
            this.Net_InvoiceTextBox.SelectedText = "";
            this.Net_InvoiceTextBox.ShadowDecoration.Parent = this.Net_InvoiceTextBox;
            this.Net_InvoiceTextBox.Size = new System.Drawing.Size(538, 36);
            this.Net_InvoiceTextBox.TabIndex = 24;
            this.toolTip1.SetToolTip(this.Net_InvoiceTextBox, "Enter invoice nmber ");
            // 
            // Net_CommentTextBox
            // 
            this.Net_CommentTextBox.Animated = true;
            this.Net_CommentTextBox.AutoRoundedCorners = true;
            this.Net_CommentTextBox.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.Net_CommentTextBox.BorderRadius = 17;
            this.Net_CommentTextBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Transition.SetDecoration(this.Net_CommentTextBox, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Net_CommentTextBox.DefaultText = "";
            this.Net_CommentTextBox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Net_CommentTextBox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Net_CommentTextBox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Net_CommentTextBox.DisabledState.Parent = this.Net_CommentTextBox;
            this.Net_CommentTextBox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Net_CommentTextBox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Net_CommentTextBox.FocusedState.Parent = this.Net_CommentTextBox;
            this.Net_CommentTextBox.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.Net_CommentTextBox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Net_CommentTextBox.HoverState.Parent = this.Net_CommentTextBox;
            this.Net_CommentTextBox.IconLeft = global::OnlineBanking_System.Properties.Resources.comments;
            this.Net_CommentTextBox.Location = new System.Drawing.Point(323, 261);
            this.Net_CommentTextBox.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.Net_CommentTextBox.Name = "Net_CommentTextBox";
            this.Net_CommentTextBox.PasswordChar = '\0';
            this.Net_CommentTextBox.PlaceholderText = "Comment.......";
            this.Net_CommentTextBox.SelectedText = "";
            this.Net_CommentTextBox.ShadowDecoration.Parent = this.Net_CommentTextBox;
            this.Net_CommentTextBox.Size = new System.Drawing.Size(538, 36);
            this.Net_CommentTextBox.TabIndex = 23;
            this.toolTip1.SetToolTip(this.Net_CommentTextBox, "If you have any comment please write it on the box ");
            // 
            // Net_AmountTextBox
            // 
            this.Net_AmountTextBox.Animated = true;
            this.Net_AmountTextBox.AutoRoundedCorners = true;
            this.Net_AmountTextBox.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.Net_AmountTextBox.BorderRadius = 17;
            this.Net_AmountTextBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Transition.SetDecoration(this.Net_AmountTextBox, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Net_AmountTextBox.DefaultText = "";
            this.Net_AmountTextBox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Net_AmountTextBox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Net_AmountTextBox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Net_AmountTextBox.DisabledState.Parent = this.Net_AmountTextBox;
            this.Net_AmountTextBox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Net_AmountTextBox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Net_AmountTextBox.FocusedState.Parent = this.Net_AmountTextBox;
            this.Net_AmountTextBox.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.Net_AmountTextBox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Net_AmountTextBox.HoverState.Parent = this.Net_AmountTextBox;
            this.Net_AmountTextBox.IconLeft = global::OnlineBanking_System.Properties.Resources.receive_amount1;
            this.Net_AmountTextBox.Location = new System.Drawing.Point(323, 198);
            this.Net_AmountTextBox.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.Net_AmountTextBox.Name = "Net_AmountTextBox";
            this.Net_AmountTextBox.PasswordChar = '\0';
            this.Net_AmountTextBox.PlaceholderText = "Enter the amount";
            this.Net_AmountTextBox.SelectedText = "";
            this.Net_AmountTextBox.ShadowDecoration.Parent = this.Net_AmountTextBox;
            this.Net_AmountTextBox.Size = new System.Drawing.Size(538, 36);
            this.Net_AmountTextBox.TabIndex = 22;
            this.toolTip1.SetToolTip(this.Net_AmountTextBox, "Amount ");
            // 
            // Net_HistoryBtn
            // 
            this.Net_HistoryBtn.Animated = true;
            this.Net_HistoryBtn.AutoRoundedCorners = true;
            this.Net_HistoryBtn.BorderRadius = 21;
            this.Net_HistoryBtn.CheckedState.Parent = this.Net_HistoryBtn;
            this.Net_HistoryBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Net_HistoryBtn.CustomImages.Parent = this.Net_HistoryBtn;
            this.Transition.SetDecoration(this.Net_HistoryBtn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Net_HistoryBtn.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.Net_HistoryBtn.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold);
            this.Net_HistoryBtn.ForeColor = System.Drawing.Color.White;
            this.Net_HistoryBtn.HoverState.Parent = this.Net_HistoryBtn;
            this.Net_HistoryBtn.Image = global::OnlineBanking_System.Properties.Resources.certificate;
            this.Net_HistoryBtn.ImageOffset = new System.Drawing.Point(-2, 0);
            this.Net_HistoryBtn.ImageSize = new System.Drawing.Size(30, 30);
            this.Net_HistoryBtn.Location = new System.Drawing.Point(730, 350);
            this.Net_HistoryBtn.Name = "Net_HistoryBtn";
            this.Net_HistoryBtn.ShadowDecoration.Parent = this.Net_HistoryBtn;
            this.Net_HistoryBtn.Size = new System.Drawing.Size(180, 45);
            this.Net_HistoryBtn.TabIndex = 21;
            this.Net_HistoryBtn.Text = "History";
            this.Net_HistoryBtn.TextOffset = new System.Drawing.Point(-2, 0);
            this.toolTip1.SetToolTip(this.Net_HistoryBtn, "Transactions History");
            this.Net_HistoryBtn.Click += new System.EventHandler(this.Net_HistoryBtn_Click);
            // 
            // Net_ClearBtn
            // 
            this.Net_ClearBtn.Animated = true;
            this.Net_ClearBtn.AutoRoundedCorners = true;
            this.Net_ClearBtn.BorderRadius = 21;
            this.Net_ClearBtn.CheckedState.Parent = this.Net_ClearBtn;
            this.Net_ClearBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Net_ClearBtn.CustomImages.Parent = this.Net_ClearBtn;
            this.Transition.SetDecoration(this.Net_ClearBtn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Net_ClearBtn.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.Net_ClearBtn.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold);
            this.Net_ClearBtn.ForeColor = System.Drawing.Color.White;
            this.Net_ClearBtn.HoverState.Parent = this.Net_ClearBtn;
            this.Net_ClearBtn.Image = global::OnlineBanking_System.Properties.Resources.delete;
            this.Net_ClearBtn.ImageOffset = new System.Drawing.Point(-2, 0);
            this.Net_ClearBtn.ImageSize = new System.Drawing.Size(30, 30);
            this.Net_ClearBtn.Location = new System.Drawing.Point(493, 350);
            this.Net_ClearBtn.Name = "Net_ClearBtn";
            this.Net_ClearBtn.ShadowDecoration.Parent = this.Net_ClearBtn;
            this.Net_ClearBtn.Size = new System.Drawing.Size(180, 45);
            this.Net_ClearBtn.TabIndex = 20;
            this.Net_ClearBtn.Text = "Clear";
            this.Net_ClearBtn.TextOffset = new System.Drawing.Point(-2, 0);
            this.toolTip1.SetToolTip(this.Net_ClearBtn, "Clear bill");
            this.Net_ClearBtn.Click += new System.EventHandler(this.Net_ClearBtn_Click);
            // 
            // Net_PayBtn
            // 
            this.Net_PayBtn.Animated = true;
            this.Net_PayBtn.AutoRoundedCorners = true;
            this.Net_PayBtn.BorderRadius = 21;
            this.Net_PayBtn.CheckedState.Parent = this.Net_PayBtn;
            this.Net_PayBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Net_PayBtn.CustomImages.Parent = this.Net_PayBtn;
            this.Transition.SetDecoration(this.Net_PayBtn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Net_PayBtn.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.Net_PayBtn.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold);
            this.Net_PayBtn.ForeColor = System.Drawing.Color.White;
            this.Net_PayBtn.HoverState.Parent = this.Net_PayBtn;
            this.Net_PayBtn.Image = global::OnlineBanking_System.Properties.Resources.cash_payment;
            this.Net_PayBtn.ImageOffset = new System.Drawing.Point(-5, 0);
            this.Net_PayBtn.ImageSize = new System.Drawing.Size(30, 30);
            this.Net_PayBtn.Location = new System.Drawing.Point(270, 350);
            this.Net_PayBtn.Name = "Net_PayBtn";
            this.Net_PayBtn.ShadowDecoration.Parent = this.Net_PayBtn;
            this.Net_PayBtn.Size = new System.Drawing.Size(180, 45);
            this.Net_PayBtn.TabIndex = 19;
            this.Net_PayBtn.Text = "Pay";
            this.Net_PayBtn.TextOffset = new System.Drawing.Point(-4, 0);
            this.toolTip1.SetToolTip(this.Net_PayBtn, "Pay bill");
            this.Net_PayBtn.Click += new System.EventHandler(this.Net_PayBtn_Click);
            // 
            // Net_Combobox
            // 
            this.Net_Combobox.Animated = true;
            this.Net_Combobox.AutoRoundedCorners = true;
            this.Net_Combobox.BackColor = System.Drawing.Color.Transparent;
            this.Net_Combobox.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.Net_Combobox.BorderRadius = 17;
            this.Net_Combobox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Transition.SetDecoration(this.Net_Combobox, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Net_Combobox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.Net_Combobox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Net_Combobox.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Net_Combobox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Net_Combobox.FocusedState.Parent = this.Net_Combobox;
            this.Net_Combobox.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.Net_Combobox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.Net_Combobox.HoverState.Parent = this.Net_Combobox;
            this.Net_Combobox.ItemHeight = 30;
            this.Net_Combobox.Items.AddRange(new object[] {
            "STC ",
            "Batelco ",
            "Zain"});
            this.Net_Combobox.ItemsAppearance.Parent = this.Net_Combobox;
            this.Net_Combobox.Location = new System.Drawing.Point(262, 71);
            this.Net_Combobox.Name = "Net_Combobox";
            this.Net_Combobox.ShadowDecoration.Parent = this.Net_Combobox;
            this.Net_Combobox.Size = new System.Drawing.Size(672, 36);
            this.Net_Combobox.TabIndex = 18;
            this.toolTip1.SetToolTip(this.Net_Combobox, "Select University Name ");
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.White;
            this.Transition.SetDecoration(this.label5, Guna.UI2.AnimatorNS.DecorationType.None);
            this.label5.Font = new System.Drawing.Font("Palatino Linotype", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.label5.Location = new System.Drawing.Point(13, 46);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(266, 67);
            this.label5.TabIndex = 17;
            this.label5.Text = "Choose Service Provider:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // MainUniversityPanel
            // 
            this.MainUniversityPanel.BackColor = System.Drawing.Color.White;
            this.MainUniversityPanel.Controls.Add(this.UniversityDatagridViewPanel);
            this.MainUniversityPanel.Controls.Add(this.UniversityInvoice_textbox);
            this.MainUniversityPanel.Controls.Add(this.UniversityComment_TextBox);
            this.MainUniversityPanel.Controls.Add(this.University_AmountTextBox);
            this.MainUniversityPanel.Controls.Add(this.University_historyBtn);
            this.MainUniversityPanel.Controls.Add(this.University_ClearBtn);
            this.MainUniversityPanel.Controls.Add(this.University_PayBtn);
            this.MainUniversityPanel.Controls.Add(this.pictureBox1);
            this.MainUniversityPanel.Controls.Add(this.UniversityName_Combobox);
            this.MainUniversityPanel.Controls.Add(this.label4);
            this.Transition.SetDecoration(this.MainUniversityPanel, Guna.UI2.AnimatorNS.DecorationType.None);
            this.MainUniversityPanel.Location = new System.Drawing.Point(3, 155);
            this.MainUniversityPanel.Name = "MainUniversityPanel";
            this.MainUniversityPanel.ShadowDecoration.Parent = this.MainUniversityPanel;
            this.MainUniversityPanel.Size = new System.Drawing.Size(1213, 457);
            this.MainUniversityPanel.TabIndex = 11;
            this.MainUniversityPanel.Visible = false;
            // 
            // UniversityDatagridViewPanel
            // 
            this.UniversityDatagridViewPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.UniversityDatagridViewPanel.Controls.Add(this.UniversityBackBtn);
            this.UniversityDatagridViewPanel.Controls.Add(this.University_SaveBtn);
            this.UniversityDatagridViewPanel.Controls.Add(this.Unversity_UpBtn);
            this.UniversityDatagridViewPanel.Controls.Add(this.University_DownBtn);
            this.UniversityDatagridViewPanel.Controls.Add(this.UniversityDatagridview);
            this.Transition.SetDecoration(this.UniversityDatagridViewPanel, Guna.UI2.AnimatorNS.DecorationType.None);
            this.UniversityDatagridViewPanel.Location = new System.Drawing.Point(0, 0);
            this.UniversityDatagridViewPanel.Name = "UniversityDatagridViewPanel";
            this.UniversityDatagridViewPanel.ShadowDecoration.Parent = this.UniversityDatagridViewPanel;
            this.UniversityDatagridViewPanel.Size = new System.Drawing.Size(1210, 454);
            this.UniversityDatagridViewPanel.TabIndex = 17;
            this.UniversityDatagridViewPanel.Visible = false;
            // 
            // UniversityBackBtn
            // 
            this.UniversityBackBtn.BackColor = System.Drawing.Color.Transparent;
            this.UniversityBackBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Transition.SetDecoration(this.UniversityBackBtn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.UniversityBackBtn.Image = global::OnlineBanking_System.Properties.Resources.back;
            this.UniversityBackBtn.Location = new System.Drawing.Point(1138, 8);
            this.UniversityBackBtn.Name = "UniversityBackBtn";
            this.UniversityBackBtn.ShadowDecoration.Parent = this.UniversityBackBtn;
            this.UniversityBackBtn.Size = new System.Drawing.Size(48, 48);
            this.UniversityBackBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.UniversityBackBtn.TabIndex = 4;
            this.UniversityBackBtn.TabStop = false;
            this.toolTip1.SetToolTip(this.UniversityBackBtn, "Return to University section");
            this.UniversityBackBtn.UseTransparentBackground = true;
            this.UniversityBackBtn.Click += new System.EventHandler(this.UniversityBackBtn_Click);
            // 
            // University_SaveBtn
            // 
            this.University_SaveBtn.Animated = true;
            this.University_SaveBtn.AutoRoundedCorners = true;
            this.University_SaveBtn.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.University_SaveBtn.BorderRadius = 22;
            this.University_SaveBtn.BorderThickness = 2;
            this.University_SaveBtn.CheckedState.Parent = this.University_SaveBtn;
            this.University_SaveBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.University_SaveBtn.CustomImages.Parent = this.University_SaveBtn;
            this.Transition.SetDecoration(this.University_SaveBtn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.University_SaveBtn.FillColor = System.Drawing.Color.White;
            this.University_SaveBtn.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.University_SaveBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.University_SaveBtn.HoverState.BorderColor = System.Drawing.Color.White;
            this.University_SaveBtn.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.University_SaveBtn.HoverState.ForeColor = System.Drawing.Color.White;
            this.University_SaveBtn.HoverState.Parent = this.University_SaveBtn;
            this.University_SaveBtn.Location = new System.Drawing.Point(941, 201);
            this.University_SaveBtn.Name = "University_SaveBtn";
            this.University_SaveBtn.ShadowDecoration.Parent = this.University_SaveBtn;
            this.University_SaveBtn.Size = new System.Drawing.Size(133, 46);
            this.University_SaveBtn.TabIndex = 3;
            this.University_SaveBtn.Text = "Save";
            this.toolTip1.SetToolTip(this.University_SaveBtn, "Save information");
            this.University_SaveBtn.Click += new System.EventHandler(this.University_SaveBtn_Click);
            // 
            // Unversity_UpBtn
            // 
            this.Unversity_UpBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Transition.SetDecoration(this.Unversity_UpBtn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Unversity_UpBtn.Image = global::OnlineBanking_System.Properties.Resources.down_chevron;
            this.Unversity_UpBtn.ImageFlip = Guna.UI2.WinForms.Enums.FlipOrientation.Vertical;
            this.Unversity_UpBtn.Location = new System.Drawing.Point(973, 59);
            this.Unversity_UpBtn.Name = "Unversity_UpBtn";
            this.Unversity_UpBtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.Unversity_UpBtn.ShadowDecoration.Parent = this.Unversity_UpBtn;
            this.Unversity_UpBtn.Size = new System.Drawing.Size(62, 69);
            this.Unversity_UpBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Unversity_UpBtn.TabIndex = 2;
            this.Unversity_UpBtn.TabStop = false;
            this.toolTip1.SetToolTip(this.Unversity_UpBtn, "Up");
            this.Unversity_UpBtn.UseTransparentBackground = true;
            this.Unversity_UpBtn.Click += new System.EventHandler(this.Unversity_UpBtn_Click);
            // 
            // University_DownBtn
            // 
            this.University_DownBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Transition.SetDecoration(this.University_DownBtn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.University_DownBtn.Image = global::OnlineBanking_System.Properties.Resources.down_chevron;
            this.University_DownBtn.Location = new System.Drawing.Point(973, 314);
            this.University_DownBtn.Name = "University_DownBtn";
            this.University_DownBtn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.University_DownBtn.ShadowDecoration.Parent = this.University_DownBtn;
            this.University_DownBtn.Size = new System.Drawing.Size(62, 69);
            this.University_DownBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.University_DownBtn.TabIndex = 1;
            this.University_DownBtn.TabStop = false;
            this.toolTip1.SetToolTip(this.University_DownBtn, "Down");
            this.University_DownBtn.UseTransparentBackground = true;
            this.University_DownBtn.Click += new System.EventHandler(this.University_DownBtn_Click);
            // 
            // UniversityDatagridview
            // 
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            this.UniversityDatagridview.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.UniversityDatagridview.AutoGenerateColumns = false;
            this.UniversityDatagridview.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.UniversityDatagridview.BackgroundColor = System.Drawing.Color.White;
            this.UniversityDatagridview.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.UniversityDatagridview.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.UniversityDatagridview.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.UniversityDatagridview.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.UniversityDatagridview.ColumnHeadersHeight = 21;
            this.UniversityDatagridview.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn1,
            this.shopNameDataGridViewTextBoxColumn1,
            this.invoiceNoDataGridViewTextBoxColumn1,
            this.commentDataGridViewTextBoxColumn1,
            this.userNameDataGridViewTextBoxColumn1});
            this.UniversityDatagridview.DataSource = this.paysBindingSource;
            this.Transition.SetDecoration(this.UniversityDatagridview, Guna.UI2.AnimatorNS.DecorationType.None);
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.UniversityDatagridview.DefaultCellStyle = dataGridViewCellStyle6;
            this.UniversityDatagridview.Dock = System.Windows.Forms.DockStyle.Left;
            this.UniversityDatagridview.EnableHeadersVisualStyles = false;
            this.UniversityDatagridview.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.UniversityDatagridview.Location = new System.Drawing.Point(0, 0);
            this.UniversityDatagridview.Name = "UniversityDatagridview";
            this.UniversityDatagridview.RowHeadersVisible = false;
            this.UniversityDatagridview.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.UniversityDatagridview.Size = new System.Drawing.Size(837, 454);
            this.UniversityDatagridview.TabIndex = 0;
            this.UniversityDatagridview.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.Default;
            this.UniversityDatagridview.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.UniversityDatagridview.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.UniversityDatagridview.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.UniversityDatagridview.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.UniversityDatagridview.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.UniversityDatagridview.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.UniversityDatagridview.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.UniversityDatagridview.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.UniversityDatagridview.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.UniversityDatagridview.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.UniversityDatagridview.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.UniversityDatagridview.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.UniversityDatagridview.ThemeStyle.HeaderStyle.Height = 21;
            this.UniversityDatagridview.ThemeStyle.ReadOnly = false;
            this.UniversityDatagridview.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.UniversityDatagridview.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.UniversityDatagridview.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.UniversityDatagridview.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.UniversityDatagridview.ThemeStyle.RowsStyle.Height = 22;
            this.UniversityDatagridview.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.UniversityDatagridview.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            // 
            // idDataGridViewTextBoxColumn1
            // 
            this.idDataGridViewTextBoxColumn1.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn1.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn1.Name = "idDataGridViewTextBoxColumn1";
            this.idDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // shopNameDataGridViewTextBoxColumn1
            // 
            this.shopNameDataGridViewTextBoxColumn1.DataPropertyName = "Shop Name ";
            this.shopNameDataGridViewTextBoxColumn1.HeaderText = "Shop Name ";
            this.shopNameDataGridViewTextBoxColumn1.Name = "shopNameDataGridViewTextBoxColumn1";
            // 
            // invoiceNoDataGridViewTextBoxColumn1
            // 
            this.invoiceNoDataGridViewTextBoxColumn1.DataPropertyName = "Invoice No";
            this.invoiceNoDataGridViewTextBoxColumn1.HeaderText = "Invoice No";
            this.invoiceNoDataGridViewTextBoxColumn1.Name = "invoiceNoDataGridViewTextBoxColumn1";
            // 
            // commentDataGridViewTextBoxColumn1
            // 
            this.commentDataGridViewTextBoxColumn1.DataPropertyName = "Comment";
            this.commentDataGridViewTextBoxColumn1.HeaderText = "Comment";
            this.commentDataGridViewTextBoxColumn1.Name = "commentDataGridViewTextBoxColumn1";
            // 
            // userNameDataGridViewTextBoxColumn1
            // 
            this.userNameDataGridViewTextBoxColumn1.DataPropertyName = "User_Name";
            this.userNameDataGridViewTextBoxColumn1.HeaderText = "User_Name";
            this.userNameDataGridViewTextBoxColumn1.Name = "userNameDataGridViewTextBoxColumn1";
            // 
            // UniversityInvoice_textbox
            // 
            this.UniversityInvoice_textbox.Animated = true;
            this.UniversityInvoice_textbox.AutoRoundedCorners = true;
            this.UniversityInvoice_textbox.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.UniversityInvoice_textbox.BorderRadius = 17;
            this.UniversityInvoice_textbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Transition.SetDecoration(this.UniversityInvoice_textbox, Guna.UI2.AnimatorNS.DecorationType.None);
            this.UniversityInvoice_textbox.DefaultText = "";
            this.UniversityInvoice_textbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.UniversityInvoice_textbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.UniversityInvoice_textbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.UniversityInvoice_textbox.DisabledState.Parent = this.UniversityInvoice_textbox;
            this.UniversityInvoice_textbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.UniversityInvoice_textbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.UniversityInvoice_textbox.FocusedState.Parent = this.UniversityInvoice_textbox;
            this.UniversityInvoice_textbox.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.UniversityInvoice_textbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.UniversityInvoice_textbox.HoverState.Parent = this.UniversityInvoice_textbox;
            this.UniversityInvoice_textbox.IconLeft = global::OnlineBanking_System.Properties.Resources.financial;
            this.UniversityInvoice_textbox.Location = new System.Drawing.Point(359, 96);
            this.UniversityInvoice_textbox.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.UniversityInvoice_textbox.Name = "UniversityInvoice_textbox";
            this.UniversityInvoice_textbox.PasswordChar = '\0';
            this.UniversityInvoice_textbox.PlaceholderText = "Enter the invoice No";
            this.UniversityInvoice_textbox.SelectedText = "";
            this.UniversityInvoice_textbox.ShadowDecoration.Parent = this.UniversityInvoice_textbox;
            this.UniversityInvoice_textbox.Size = new System.Drawing.Size(538, 36);
            this.UniversityInvoice_textbox.TabIndex = 16;
            this.toolTip1.SetToolTip(this.UniversityInvoice_textbox, "Enter invoice nmber ");
            // 
            // UniversityComment_TextBox
            // 
            this.UniversityComment_TextBox.Animated = true;
            this.UniversityComment_TextBox.AutoRoundedCorners = true;
            this.UniversityComment_TextBox.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.UniversityComment_TextBox.BorderRadius = 17;
            this.UniversityComment_TextBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Transition.SetDecoration(this.UniversityComment_TextBox, Guna.UI2.AnimatorNS.DecorationType.None);
            this.UniversityComment_TextBox.DefaultText = "";
            this.UniversityComment_TextBox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.UniversityComment_TextBox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.UniversityComment_TextBox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.UniversityComment_TextBox.DisabledState.Parent = this.UniversityComment_TextBox;
            this.UniversityComment_TextBox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.UniversityComment_TextBox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.UniversityComment_TextBox.FocusedState.Parent = this.UniversityComment_TextBox;
            this.UniversityComment_TextBox.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.UniversityComment_TextBox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.UniversityComment_TextBox.HoverState.Parent = this.UniversityComment_TextBox;
            this.UniversityComment_TextBox.IconLeft = global::OnlineBanking_System.Properties.Resources.comments;
            this.UniversityComment_TextBox.Location = new System.Drawing.Point(359, 220);
            this.UniversityComment_TextBox.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.UniversityComment_TextBox.Name = "UniversityComment_TextBox";
            this.UniversityComment_TextBox.PasswordChar = '\0';
            this.UniversityComment_TextBox.PlaceholderText = "Comment.......";
            this.UniversityComment_TextBox.SelectedText = "";
            this.UniversityComment_TextBox.ShadowDecoration.Parent = this.UniversityComment_TextBox;
            this.UniversityComment_TextBox.Size = new System.Drawing.Size(538, 36);
            this.UniversityComment_TextBox.TabIndex = 15;
            this.toolTip1.SetToolTip(this.UniversityComment_TextBox, "If you have any comment please write it on the box ");
            // 
            // University_AmountTextBox
            // 
            this.University_AmountTextBox.Animated = true;
            this.University_AmountTextBox.AutoRoundedCorners = true;
            this.University_AmountTextBox.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.University_AmountTextBox.BorderRadius = 17;
            this.University_AmountTextBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Transition.SetDecoration(this.University_AmountTextBox, Guna.UI2.AnimatorNS.DecorationType.None);
            this.University_AmountTextBox.DefaultText = "";
            this.University_AmountTextBox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.University_AmountTextBox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.University_AmountTextBox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.University_AmountTextBox.DisabledState.Parent = this.University_AmountTextBox;
            this.University_AmountTextBox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.University_AmountTextBox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.University_AmountTextBox.FocusedState.Parent = this.University_AmountTextBox;
            this.University_AmountTextBox.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.University_AmountTextBox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.University_AmountTextBox.HoverState.Parent = this.University_AmountTextBox;
            this.University_AmountTextBox.IconLeft = global::OnlineBanking_System.Properties.Resources.receive_amount1;
            this.University_AmountTextBox.Location = new System.Drawing.Point(359, 157);
            this.University_AmountTextBox.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.University_AmountTextBox.Name = "University_AmountTextBox";
            this.University_AmountTextBox.PasswordChar = '\0';
            this.University_AmountTextBox.PlaceholderText = "Enter the amount";
            this.University_AmountTextBox.SelectedText = "";
            this.University_AmountTextBox.ShadowDecoration.Parent = this.University_AmountTextBox;
            this.University_AmountTextBox.Size = new System.Drawing.Size(538, 36);
            this.University_AmountTextBox.TabIndex = 14;
            this.toolTip1.SetToolTip(this.University_AmountTextBox, "Amount ");
            // 
            // University_historyBtn
            // 
            this.University_historyBtn.Animated = true;
            this.University_historyBtn.AutoRoundedCorners = true;
            this.University_historyBtn.BorderRadius = 21;
            this.University_historyBtn.CheckedState.Parent = this.University_historyBtn;
            this.University_historyBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.University_historyBtn.CustomImages.Parent = this.University_historyBtn;
            this.Transition.SetDecoration(this.University_historyBtn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.University_historyBtn.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.University_historyBtn.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold);
            this.University_historyBtn.ForeColor = System.Drawing.Color.White;
            this.University_historyBtn.HoverState.Parent = this.University_historyBtn;
            this.University_historyBtn.Image = global::OnlineBanking_System.Properties.Resources.certificate;
            this.University_historyBtn.ImageOffset = new System.Drawing.Point(-2, 0);
            this.University_historyBtn.ImageSize = new System.Drawing.Size(30, 30);
            this.University_historyBtn.Location = new System.Drawing.Point(766, 313);
            this.University_historyBtn.Name = "University_historyBtn";
            this.University_historyBtn.ShadowDecoration.Parent = this.University_historyBtn;
            this.University_historyBtn.Size = new System.Drawing.Size(180, 45);
            this.University_historyBtn.TabIndex = 13;
            this.University_historyBtn.Text = "History";
            this.University_historyBtn.TextOffset = new System.Drawing.Point(-2, 0);
            this.toolTip1.SetToolTip(this.University_historyBtn, "Transactions History");
            this.University_historyBtn.Click += new System.EventHandler(this.University_historyBtn_Click);
            // 
            // University_ClearBtn
            // 
            this.University_ClearBtn.Animated = true;
            this.University_ClearBtn.AutoRoundedCorners = true;
            this.University_ClearBtn.BorderRadius = 21;
            this.University_ClearBtn.CheckedState.Parent = this.University_ClearBtn;
            this.University_ClearBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.University_ClearBtn.CustomImages.Parent = this.University_ClearBtn;
            this.Transition.SetDecoration(this.University_ClearBtn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.University_ClearBtn.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.University_ClearBtn.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold);
            this.University_ClearBtn.ForeColor = System.Drawing.Color.White;
            this.University_ClearBtn.HoverState.Parent = this.University_ClearBtn;
            this.University_ClearBtn.Image = global::OnlineBanking_System.Properties.Resources.delete;
            this.University_ClearBtn.ImageOffset = new System.Drawing.Point(-2, 0);
            this.University_ClearBtn.ImageSize = new System.Drawing.Size(30, 30);
            this.University_ClearBtn.Location = new System.Drawing.Point(529, 313);
            this.University_ClearBtn.Name = "University_ClearBtn";
            this.University_ClearBtn.ShadowDecoration.Parent = this.University_ClearBtn;
            this.University_ClearBtn.Size = new System.Drawing.Size(180, 45);
            this.University_ClearBtn.TabIndex = 12;
            this.University_ClearBtn.Text = "Clear";
            this.University_ClearBtn.TextOffset = new System.Drawing.Point(-2, 0);
            this.toolTip1.SetToolTip(this.University_ClearBtn, "Clear bill");
            this.University_ClearBtn.Click += new System.EventHandler(this.University_ClearBtn_Click);
            // 
            // University_PayBtn
            // 
            this.University_PayBtn.Animated = true;
            this.University_PayBtn.AutoRoundedCorners = true;
            this.University_PayBtn.BorderRadius = 21;
            this.University_PayBtn.CheckedState.Parent = this.University_PayBtn;
            this.University_PayBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.University_PayBtn.CustomImages.Parent = this.University_PayBtn;
            this.Transition.SetDecoration(this.University_PayBtn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.University_PayBtn.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.University_PayBtn.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold);
            this.University_PayBtn.ForeColor = System.Drawing.Color.White;
            this.University_PayBtn.HoverState.Parent = this.University_PayBtn;
            this.University_PayBtn.Image = global::OnlineBanking_System.Properties.Resources.cash_payment;
            this.University_PayBtn.ImageOffset = new System.Drawing.Point(-5, 0);
            this.University_PayBtn.ImageSize = new System.Drawing.Size(30, 30);
            this.University_PayBtn.Location = new System.Drawing.Point(270, 313);
            this.University_PayBtn.Name = "University_PayBtn";
            this.University_PayBtn.ShadowDecoration.Parent = this.University_PayBtn;
            this.University_PayBtn.Size = new System.Drawing.Size(180, 45);
            this.University_PayBtn.TabIndex = 11;
            this.University_PayBtn.Text = "Pay";
            this.University_PayBtn.TextOffset = new System.Drawing.Point(-4, 0);
            this.toolTip1.SetToolTip(this.University_PayBtn, "Pay bill");
            this.University_PayBtn.Click += new System.EventHandler(this.University_PayBtn_Click);
            // 
            // pictureBox1
            // 
            this.Transition.SetDecoration(this.pictureBox1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.pictureBox1.Image = global::OnlineBanking_System.Properties.Resources.teamwork__1_;
            this.pictureBox1.Location = new System.Drawing.Point(1011, 51);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(163, 182);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // UniversityName_Combobox
            // 
            this.UniversityName_Combobox.Animated = true;
            this.UniversityName_Combobox.AutoRoundedCorners = true;
            this.UniversityName_Combobox.BackColor = System.Drawing.Color.Transparent;
            this.UniversityName_Combobox.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.UniversityName_Combobox.BorderRadius = 17;
            this.UniversityName_Combobox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Transition.SetDecoration(this.UniversityName_Combobox, Guna.UI2.AnimatorNS.DecorationType.None);
            this.UniversityName_Combobox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.UniversityName_Combobox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.UniversityName_Combobox.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.UniversityName_Combobox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.UniversityName_Combobox.FocusedState.Parent = this.UniversityName_Combobox;
            this.UniversityName_Combobox.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.UniversityName_Combobox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.UniversityName_Combobox.HoverState.Parent = this.UniversityName_Combobox;
            this.UniversityName_Combobox.ItemHeight = 30;
            this.UniversityName_Combobox.Items.AddRange(new object[] {
            "University of Bahrain",
            "Arabian Gulf University",
            "ASU University",
            "Bahrain Polytechnic University",
            "AMA University"});
            this.UniversityName_Combobox.ItemsAppearance.Parent = this.UniversityName_Combobox;
            this.UniversityName_Combobox.Location = new System.Drawing.Point(298, 30);
            this.UniversityName_Combobox.Name = "UniversityName_Combobox";
            this.UniversityName_Combobox.ShadowDecoration.Parent = this.UniversityName_Combobox;
            this.UniversityName_Combobox.Size = new System.Drawing.Size(672, 36);
            this.UniversityName_Combobox.TabIndex = 4;
            this.toolTip1.SetToolTip(this.UniversityName_Combobox, "Select University Name ");
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.White;
            this.Transition.SetDecoration(this.label4, Guna.UI2.AnimatorNS.DecorationType.None);
            this.label4.Font = new System.Drawing.Font("Palatino Linotype", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.label4.Location = new System.Drawing.Point(12, 13);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(291, 67);
            this.label4.TabIndex = 3;
            this.label4.Text = "Choose University :";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // MainMarketPanel
            // 
            this.MainMarketPanel.Controls.Add(this.Market_panel);
            this.MainMarketPanel.Controls.Add(this.Markets_DataGrid_panel);
            this.Transition.SetDecoration(this.MainMarketPanel, Guna.UI2.AnimatorNS.DecorationType.None);
            this.MainMarketPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.MainMarketPanel.Location = new System.Drawing.Point(0, 160);
            this.MainMarketPanel.Name = "MainMarketPanel";
            this.MainMarketPanel.ShadowDecoration.Parent = this.MainMarketPanel;
            this.MainMarketPanel.Size = new System.Drawing.Size(1216, 457);
            this.MainMarketPanel.TabIndex = 5;
            // 
            // Market_panel
            // 
            this.Market_panel.Controls.Add(this.Market_History_btn);
            this.Market_panel.Controls.Add(this.Clear_btn);
            this.Market_panel.Controls.Add(this.Pay_btn);
            this.Market_panel.Controls.Add(this.Invoice_textBox);
            this.Market_panel.Controls.Add(this.Comment_textBoxx);
            this.Market_panel.Controls.Add(this.guna2PictureBox1);
            this.Market_panel.Controls.Add(this.label3);
            this.Market_panel.Controls.Add(this.Amount_textBox);
            this.Market_panel.Controls.Add(this.Markets_combbox);
            this.Transition.SetDecoration(this.Market_panel, Guna.UI2.AnimatorNS.DecorationType.BottomMirror);
            this.Market_panel.Dock = System.Windows.Forms.DockStyle.Top;
            this.Market_panel.Location = new System.Drawing.Point(0, 0);
            this.Market_panel.Name = "Market_panel";
            this.Market_panel.ShadowDecoration.Parent = this.Market_panel;
            this.Market_panel.Size = new System.Drawing.Size(1216, 452);
            this.Market_panel.TabIndex = 1;
            // 
            // Market_History_btn
            // 
            this.Market_History_btn.Animated = true;
            this.Market_History_btn.AutoRoundedCorners = true;
            this.Market_History_btn.BorderRadius = 21;
            this.Market_History_btn.CheckedState.Parent = this.Market_History_btn;
            this.Market_History_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Market_History_btn.CustomImages.Parent = this.Market_History_btn;
            this.Transition.SetDecoration(this.Market_History_btn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Market_History_btn.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.Market_History_btn.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold);
            this.Market_History_btn.ForeColor = System.Drawing.Color.White;
            this.Market_History_btn.HoverState.Parent = this.Market_History_btn;
            this.Market_History_btn.Image = global::OnlineBanking_System.Properties.Resources.certificate;
            this.Market_History_btn.ImageOffset = new System.Drawing.Point(-2, 0);
            this.Market_History_btn.ImageSize = new System.Drawing.Size(30, 30);
            this.Market_History_btn.Location = new System.Drawing.Point(757, 373);
            this.Market_History_btn.Name = "Market_History_btn";
            this.Market_History_btn.ShadowDecoration.Parent = this.Market_History_btn;
            this.Market_History_btn.Size = new System.Drawing.Size(180, 45);
            this.Market_History_btn.TabIndex = 10;
            this.Market_History_btn.Text = "History";
            this.Market_History_btn.TextOffset = new System.Drawing.Point(-2, 0);
            this.toolTip1.SetToolTip(this.Market_History_btn, "Transactions History");
            this.Market_History_btn.Click += new System.EventHandler(this.Market_History_btn_Click);
            // 
            // Clear_btn
            // 
            this.Clear_btn.Animated = true;
            this.Clear_btn.AutoRoundedCorners = true;
            this.Clear_btn.BorderRadius = 21;
            this.Clear_btn.CheckedState.Parent = this.Clear_btn;
            this.Clear_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Clear_btn.CustomImages.Parent = this.Clear_btn;
            this.Transition.SetDecoration(this.Clear_btn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Clear_btn.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.Clear_btn.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold);
            this.Clear_btn.ForeColor = System.Drawing.Color.White;
            this.Clear_btn.HoverState.Parent = this.Clear_btn;
            this.Clear_btn.Image = global::OnlineBanking_System.Properties.Resources.delete;
            this.Clear_btn.ImageOffset = new System.Drawing.Point(-2, 0);
            this.Clear_btn.ImageSize = new System.Drawing.Size(30, 30);
            this.Clear_btn.Location = new System.Drawing.Point(520, 373);
            this.Clear_btn.Name = "Clear_btn";
            this.Clear_btn.ShadowDecoration.Parent = this.Clear_btn;
            this.Clear_btn.Size = new System.Drawing.Size(180, 45);
            this.Clear_btn.TabIndex = 9;
            this.Clear_btn.Text = "Clear";
            this.Clear_btn.TextOffset = new System.Drawing.Point(-2, 0);
            this.toolTip1.SetToolTip(this.Clear_btn, "Clear bill");
            this.Clear_btn.Click += new System.EventHandler(this.Clear_btn_Click);
            // 
            // Pay_btn
            // 
            this.Pay_btn.Animated = true;
            this.Pay_btn.AutoRoundedCorners = true;
            this.Pay_btn.BorderRadius = 21;
            this.Pay_btn.CheckedState.Parent = this.Pay_btn;
            this.Pay_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Pay_btn.CustomImages.Parent = this.Pay_btn;
            this.Transition.SetDecoration(this.Pay_btn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Pay_btn.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.Pay_btn.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold);
            this.Pay_btn.ForeColor = System.Drawing.Color.White;
            this.Pay_btn.HoverState.Parent = this.Pay_btn;
            this.Pay_btn.Image = global::OnlineBanking_System.Properties.Resources.cash_payment;
            this.Pay_btn.ImageOffset = new System.Drawing.Point(-5, 0);
            this.Pay_btn.ImageSize = new System.Drawing.Size(30, 30);
            this.Pay_btn.Location = new System.Drawing.Point(261, 373);
            this.Pay_btn.Name = "Pay_btn";
            this.Pay_btn.ShadowDecoration.Parent = this.Pay_btn;
            this.Pay_btn.Size = new System.Drawing.Size(180, 45);
            this.Pay_btn.TabIndex = 8;
            this.Pay_btn.Text = "Pay";
            this.Pay_btn.TextOffset = new System.Drawing.Point(-4, 0);
            this.toolTip1.SetToolTip(this.Pay_btn, "Pay bill");
            this.Pay_btn.Click += new System.EventHandler(this.Pay_btn_Click);
            // 
            // Invoice_textBox
            // 
            this.Invoice_textBox.Animated = true;
            this.Invoice_textBox.AutoRoundedCorners = true;
            this.Invoice_textBox.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.Invoice_textBox.BorderRadius = 17;
            this.Invoice_textBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Transition.SetDecoration(this.Invoice_textBox, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Invoice_textBox.DefaultText = "";
            this.Invoice_textBox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Invoice_textBox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Invoice_textBox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Invoice_textBox.DisabledState.Parent = this.Invoice_textBox;
            this.Invoice_textBox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Invoice_textBox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Invoice_textBox.FocusedState.Parent = this.Invoice_textBox;
            this.Invoice_textBox.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.Invoice_textBox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Invoice_textBox.HoverState.Parent = this.Invoice_textBox;
            this.Invoice_textBox.IconLeft = global::OnlineBanking_System.Properties.Resources.financial;
            this.Invoice_textBox.Location = new System.Drawing.Point(305, 157);
            this.Invoice_textBox.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.Invoice_textBox.Name = "Invoice_textBox";
            this.Invoice_textBox.PasswordChar = '\0';
            this.Invoice_textBox.PlaceholderText = "Enter the invoice No";
            this.Invoice_textBox.SelectedText = "";
            this.Invoice_textBox.ShadowDecoration.Parent = this.Invoice_textBox;
            this.Invoice_textBox.Size = new System.Drawing.Size(538, 36);
            this.Invoice_textBox.TabIndex = 5;
            // 
            // Comment_textBoxx
            // 
            this.Comment_textBoxx.Animated = true;
            this.Comment_textBoxx.AutoRoundedCorners = true;
            this.Comment_textBoxx.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.Comment_textBoxx.BorderRadius = 17;
            this.Comment_textBoxx.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Transition.SetDecoration(this.Comment_textBoxx, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Comment_textBoxx.DefaultText = "";
            this.Comment_textBoxx.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Comment_textBoxx.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Comment_textBoxx.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Comment_textBoxx.DisabledState.Parent = this.Comment_textBoxx;
            this.Comment_textBoxx.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Comment_textBoxx.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Comment_textBoxx.FocusedState.Parent = this.Comment_textBoxx;
            this.Comment_textBoxx.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.Comment_textBoxx.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Comment_textBoxx.HoverState.Parent = this.Comment_textBoxx;
            this.Comment_textBoxx.IconLeft = global::OnlineBanking_System.Properties.Resources.comments;
            this.Comment_textBoxx.Location = new System.Drawing.Point(305, 281);
            this.Comment_textBoxx.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.Comment_textBoxx.Name = "Comment_textBoxx";
            this.Comment_textBoxx.PasswordChar = '\0';
            this.Comment_textBoxx.PlaceholderText = "Comment.......";
            this.Comment_textBoxx.SelectedText = "";
            this.Comment_textBoxx.ShadowDecoration.Parent = this.Comment_textBoxx;
            this.Comment_textBoxx.Size = new System.Drawing.Size(538, 36);
            this.Comment_textBoxx.TabIndex = 4;
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.Transition.SetDecoration(this.guna2PictureBox1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2PictureBox1.Image = global::OnlineBanking_System.Properties.Resources.store;
            this.guna2PictureBox1.Location = new System.Drawing.Point(1029, 6);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.ShadowDecoration.Parent = this.guna2PictureBox1;
            this.guna2PictureBox1.Size = new System.Drawing.Size(148, 151);
            this.guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox1.TabIndex = 7;
            this.guna2PictureBox1.TabStop = false;
            this.guna2PictureBox1.UseTransparentBackground = true;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.White;
            this.Transition.SetDecoration(this.label3, Guna.UI2.AnimatorNS.DecorationType.None);
            this.label3.Font = new System.Drawing.Font("Segoe MDL2 Assets", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.label3.Location = new System.Drawing.Point(40, 66);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(150, 39);
            this.label3.TabIndex = 6;
            this.label3.Text = "Market :";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Amount_textBox
            // 
            this.Amount_textBox.Animated = true;
            this.Amount_textBox.AutoRoundedCorners = true;
            this.Amount_textBox.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.Amount_textBox.BorderRadius = 17;
            this.Amount_textBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Transition.SetDecoration(this.Amount_textBox, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Amount_textBox.DefaultText = "";
            this.Amount_textBox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Amount_textBox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Amount_textBox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Amount_textBox.DisabledState.Parent = this.Amount_textBox;
            this.Amount_textBox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Amount_textBox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Amount_textBox.FocusedState.Parent = this.Amount_textBox;
            this.Amount_textBox.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.Amount_textBox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Amount_textBox.HoverState.Parent = this.Amount_textBox;
            this.Amount_textBox.IconLeft = global::OnlineBanking_System.Properties.Resources.receive_amount1;
            this.Amount_textBox.Location = new System.Drawing.Point(305, 218);
            this.Amount_textBox.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.Amount_textBox.Name = "Amount_textBox";
            this.Amount_textBox.PasswordChar = '\0';
            this.Amount_textBox.PlaceholderText = "Enter the amount";
            this.Amount_textBox.SelectedText = "";
            this.Amount_textBox.ShadowDecoration.Parent = this.Amount_textBox;
            this.Amount_textBox.Size = new System.Drawing.Size(538, 36);
            this.Amount_textBox.TabIndex = 2;
            // 
            // Markets_combbox
            // 
            this.Markets_combbox.Animated = true;
            this.Markets_combbox.AutoRoundedCorners = true;
            this.Markets_combbox.BackColor = System.Drawing.Color.Transparent;
            this.Markets_combbox.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.Markets_combbox.BorderRadius = 17;
            this.Markets_combbox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Transition.SetDecoration(this.Markets_combbox, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Markets_combbox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.Markets_combbox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Markets_combbox.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Markets_combbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Markets_combbox.FocusedState.Parent = this.Markets_combbox;
            this.Markets_combbox.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.Markets_combbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.Markets_combbox.HoverState.Parent = this.Markets_combbox;
            this.Markets_combbox.ItemHeight = 30;
            this.Markets_combbox.Items.AddRange(new object[] {
            "Alosra Supermarket",
            "LuLu Hypermarket",
            "Aljazeera supermarket",
            "Bahrain Briade supermarket",
            "AlHelli Supermarket",
            "Carrefour supermarket",
            "LastChance supermarket",
            "Almuntazah Supermarket"});
            this.Markets_combbox.ItemsAppearance.Parent = this.Markets_combbox;
            this.Markets_combbox.Location = new System.Drawing.Point(196, 72);
            this.Markets_combbox.Name = "Markets_combbox";
            this.Markets_combbox.ShadowDecoration.Parent = this.Markets_combbox;
            this.Markets_combbox.Size = new System.Drawing.Size(756, 36);
            this.Markets_combbox.TabIndex = 0;
            this.toolTip1.SetToolTip(this.Markets_combbox, "Choose market");
            // 
            // Markets_DataGrid_panel
            // 
            this.Markets_DataGrid_panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.Markets_DataGrid_panel.Controls.Add(this.Back_TOPanelBTN);
            this.Markets_DataGrid_panel.Controls.Add(this.Down_btn);
            this.Markets_DataGrid_panel.Controls.Add(this.Up_btn);
            this.Markets_DataGrid_panel.Controls.Add(this.save_btn);
            this.Markets_DataGrid_panel.Controls.Add(this.Market_Datagridview);
            this.Transition.SetDecoration(this.Markets_DataGrid_panel, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Markets_DataGrid_panel.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.Markets_DataGrid_panel.Location = new System.Drawing.Point(12, 13);
            this.Markets_DataGrid_panel.Name = "Markets_DataGrid_panel";
            this.Markets_DataGrid_panel.ShadowDecoration.Parent = this.Markets_DataGrid_panel;
            this.Markets_DataGrid_panel.Size = new System.Drawing.Size(166, 393);
            this.Markets_DataGrid_panel.TabIndex = 4;
            this.Markets_DataGrid_panel.Visible = false;
            // 
            // Back_TOPanelBTN
            // 
            this.Back_TOPanelBTN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.Back_TOPanelBTN.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Transition.SetDecoration(this.Back_TOPanelBTN, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Back_TOPanelBTN.Image = global::OnlineBanking_System.Properties.Resources.back;
            this.Back_TOPanelBTN.Location = new System.Drawing.Point(1129, 10);
            this.Back_TOPanelBTN.Name = "Back_TOPanelBTN";
            this.Back_TOPanelBTN.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.Back_TOPanelBTN.ShadowDecoration.Parent = this.Back_TOPanelBTN;
            this.Back_TOPanelBTN.Size = new System.Drawing.Size(54, 51);
            this.Back_TOPanelBTN.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Back_TOPanelBTN.TabIndex = 4;
            this.Back_TOPanelBTN.TabStop = false;
            this.toolTip1.SetToolTip(this.Back_TOPanelBTN, "Back to Pay ");
            this.Back_TOPanelBTN.UseTransparentBackground = true;
            this.Back_TOPanelBTN.Click += new System.EventHandler(this.Back_TOPanelBTN_Click);
            // 
            // Down_btn
            // 
            this.Down_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.Down_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Transition.SetDecoration(this.Down_btn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Down_btn.Image = global::OnlineBanking_System.Properties.Resources.down_chevron;
            this.Down_btn.Location = new System.Drawing.Point(1052, 300);
            this.Down_btn.Name = "Down_btn";
            this.Down_btn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.Down_btn.ShadowDecoration.Parent = this.Down_btn;
            this.Down_btn.Size = new System.Drawing.Size(51, 41);
            this.Down_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Down_btn.TabIndex = 3;
            this.Down_btn.TabStop = false;
            this.toolTip1.SetToolTip(this.Down_btn, "Down");
            this.Down_btn.Click += new System.EventHandler(this.Down_btn_Click);
            // 
            // Up_btn
            // 
            this.Up_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.Up_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Transition.SetDecoration(this.Up_btn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Up_btn.Image = global::OnlineBanking_System.Properties.Resources.down_chevron;
            this.Up_btn.ImageFlip = Guna.UI2.WinForms.Enums.FlipOrientation.Vertical;
            this.Up_btn.Location = new System.Drawing.Point(1052, 140);
            this.Up_btn.Name = "Up_btn";
            this.Up_btn.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.Up_btn.ShadowDecoration.Parent = this.Up_btn;
            this.Up_btn.Size = new System.Drawing.Size(51, 41);
            this.Up_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Up_btn.TabIndex = 2;
            this.Up_btn.TabStop = false;
            this.toolTip1.SetToolTip(this.Up_btn, "Up");
            this.Up_btn.Click += new System.EventHandler(this.Up_btn_Click);
            // 
            // save_btn
            // 
            this.save_btn.Animated = true;
            this.save_btn.AutoRoundedCorners = true;
            this.save_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.save_btn.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.save_btn.BorderRadius = 18;
            this.save_btn.BorderThickness = 2;
            this.save_btn.CheckedState.Parent = this.save_btn;
            this.save_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.save_btn.CustomImages.Parent = this.save_btn;
            this.Transition.SetDecoration(this.save_btn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.save_btn.FillColor = System.Drawing.Color.White;
            this.save_btn.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.save_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.save_btn.HoverState.BorderColor = System.Drawing.Color.White;
            this.save_btn.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.save_btn.HoverState.ForeColor = System.Drawing.Color.White;
            this.save_btn.HoverState.Parent = this.save_btn;
            this.save_btn.Location = new System.Drawing.Point(1028, 226);
            this.save_btn.Name = "save_btn";
            this.save_btn.ShadowDecoration.Parent = this.save_btn;
            this.save_btn.Size = new System.Drawing.Size(101, 39);
            this.save_btn.TabIndex = 1;
            this.save_btn.Text = "Save";
            this.toolTip1.SetToolTip(this.save_btn, "Save information");
            this.save_btn.Click += new System.EventHandler(this.save_btn_Click);
            // 
            // Market_Datagridview
            // 
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.White;
            this.Market_Datagridview.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle7;
            this.Market_Datagridview.AutoGenerateColumns = false;
            this.Market_Datagridview.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Market_Datagridview.BackgroundColor = System.Drawing.Color.White;
            this.Market_Datagridview.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Market_Datagridview.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.Market_Datagridview.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Market_Datagridview.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.Market_Datagridview.ColumnHeadersHeight = 21;
            this.Market_Datagridview.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.shopNameDataGridViewTextBoxColumn,
            this.invoiceNoDataGridViewTextBoxColumn,
            this.commentDataGridViewTextBoxColumn,
            this.userNameDataGridViewTextBoxColumn});
            this.Market_Datagridview.DataSource = this.paysBindingSource;
            this.Transition.SetDecoration(this.Market_Datagridview, Guna.UI2.AnimatorNS.DecorationType.None);
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Market_Datagridview.DefaultCellStyle = dataGridViewCellStyle9;
            this.Market_Datagridview.Dock = System.Windows.Forms.DockStyle.Left;
            this.Market_Datagridview.EnableHeadersVisualStyles = false;
            this.Market_Datagridview.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.Market_Datagridview.Location = new System.Drawing.Point(0, 0);
            this.Market_Datagridview.Name = "Market_Datagridview";
            this.Market_Datagridview.RowHeadersVisible = false;
            this.Market_Datagridview.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Market_Datagridview.Size = new System.Drawing.Size(961, 393);
            this.Market_Datagridview.TabIndex = 0;
            this.Market_Datagridview.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.Default;
            this.Market_Datagridview.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.Market_Datagridview.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.Market_Datagridview.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.Market_Datagridview.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.Market_Datagridview.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.Market_Datagridview.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.Market_Datagridview.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.Market_Datagridview.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.Market_Datagridview.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.Market_Datagridview.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.Market_Datagridview.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.Market_Datagridview.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.Market_Datagridview.ThemeStyle.HeaderStyle.Height = 21;
            this.Market_Datagridview.ThemeStyle.ReadOnly = false;
            this.Market_Datagridview.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.Market_Datagridview.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.Market_Datagridview.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.Market_Datagridview.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.Market_Datagridview.ThemeStyle.RowsStyle.Height = 22;
            this.Market_Datagridview.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.Market_Datagridview.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // shopNameDataGridViewTextBoxColumn
            // 
            this.shopNameDataGridViewTextBoxColumn.DataPropertyName = "Shop Name ";
            this.shopNameDataGridViewTextBoxColumn.HeaderText = "Shop Name ";
            this.shopNameDataGridViewTextBoxColumn.Name = "shopNameDataGridViewTextBoxColumn";
            // 
            // invoiceNoDataGridViewTextBoxColumn
            // 
            this.invoiceNoDataGridViewTextBoxColumn.DataPropertyName = "Invoice No";
            this.invoiceNoDataGridViewTextBoxColumn.HeaderText = "Invoice No";
            this.invoiceNoDataGridViewTextBoxColumn.Name = "invoiceNoDataGridViewTextBoxColumn";
            // 
            // commentDataGridViewTextBoxColumn
            // 
            this.commentDataGridViewTextBoxColumn.DataPropertyName = "Comment";
            this.commentDataGridViewTextBoxColumn.HeaderText = "Comment";
            this.commentDataGridViewTextBoxColumn.Name = "commentDataGridViewTextBoxColumn";
            // 
            // userNameDataGridViewTextBoxColumn
            // 
            this.userNameDataGridViewTextBoxColumn.DataPropertyName = "User_Name";
            this.userNameDataGridViewTextBoxColumn.HeaderText = "User_Name";
            this.userNameDataGridViewTextBoxColumn.Name = "userNameDataGridViewTextBoxColumn";
            // 
            // Comment_textBox
            // 
            this.Comment_textBox.Animated = true;
            this.Comment_textBox.AutoRoundedCorners = true;
            this.Comment_textBox.BorderRadius = 35;
            this.Comment_textBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Transition.SetDecoration(this.Comment_textBox, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Comment_textBox.DefaultText = "";
            this.Comment_textBox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Comment_textBox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Comment_textBox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Comment_textBox.DisabledState.Parent = this.Comment_textBox;
            this.Comment_textBox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Comment_textBox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Comment_textBox.FocusedState.Parent = this.Comment_textBox;
            this.Comment_textBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Comment_textBox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Comment_textBox.HoverState.Parent = this.Comment_textBox;
            this.Comment_textBox.Location = new System.Drawing.Point(550, 886);
            this.Comment_textBox.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.Comment_textBox.Name = "Comment_textBox";
            this.Comment_textBox.PasswordChar = '\0';
            this.Comment_textBox.PlaceholderText = "Comment........";
            this.Comment_textBox.SelectedText = "";
            this.Comment_textBox.ShadowDecoration.Parent = this.Comment_textBox;
            this.Comment_textBox.Size = new System.Drawing.Size(922, 72);
            this.Comment_textBox.TabIndex = 3;
            // 
            // one_m
            // 
            this.one_m.Controls.Add(this.DateTime_label);
            this.one_m.Controls.Add(this.guna2Separator2);
            this.one_m.Controls.Add(this.Show_Balance_btn);
            this.one_m.Controls.Add(this.AccountName_label);
            this.one_m.Controls.Add(this.label2);
            this.Transition.SetDecoration(this.one_m, Guna.UI2.AnimatorNS.DecorationType.None);
            this.one_m.Location = new System.Drawing.Point(3, 4);
            this.one_m.Name = "one_m";
            this.one_m.ShadowDecoration.Parent = this.one_m;
            this.one_m.Size = new System.Drawing.Size(1213, 155);
            this.one_m.TabIndex = 0;
            // 
            // DateTime_label
            // 
            this.DateTime_label.BackColor = System.Drawing.Color.White;
            this.Transition.SetDecoration(this.DateTime_label, Guna.UI2.AnimatorNS.DecorationType.None);
            this.DateTime_label.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DateTime_label.ForeColor = System.Drawing.Color.Gray;
            this.DateTime_label.Location = new System.Drawing.Point(830, 19);
            this.DateTime_label.Name = "DateTime_label";
            this.DateTime_label.Size = new System.Drawing.Size(356, 111);
            this.DateTime_label.TabIndex = 6;
            this.DateTime_label.Text = "Date";
            this.DateTime_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // guna2Separator2
            // 
            this.guna2Separator2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.Transition.SetDecoration(this.guna2Separator2, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2Separator2.FillColor = System.Drawing.Color.White;
            this.guna2Separator2.FillThickness = 3;
            this.guna2Separator2.Location = new System.Drawing.Point(-3, 133);
            this.guna2Separator2.Name = "guna2Separator2";
            this.guna2Separator2.Size = new System.Drawing.Size(1216, 16);
            this.guna2Separator2.TabIndex = 3;
            // 
            // Show_Balance_btn
            // 
            this.Show_Balance_btn.CheckedState.Parent = this.Show_Balance_btn;
            this.Show_Balance_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Show_Balance_btn.CustomImages.Parent = this.Show_Balance_btn;
            this.Transition.SetDecoration(this.Show_Balance_btn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Show_Balance_btn.FillColor = System.Drawing.Color.White;
            this.Show_Balance_btn.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Show_Balance_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.Show_Balance_btn.HoverState.Parent = this.Show_Balance_btn;
            this.Show_Balance_btn.Image = global::OnlineBanking_System.Properties.Resources.view1;
            this.Show_Balance_btn.Location = new System.Drawing.Point(78, 85);
            this.Show_Balance_btn.Name = "Show_Balance_btn";
            this.Show_Balance_btn.ShadowDecoration.Parent = this.Show_Balance_btn;
            this.Show_Balance_btn.Size = new System.Drawing.Size(279, 45);
            this.Show_Balance_btn.TabIndex = 5;
            this.Show_Balance_btn.Text = "Show account Balance";
            this.toolTip1.SetToolTip(this.Show_Balance_btn, "Show account balance");
            this.Show_Balance_btn.Click += new System.EventHandler(this.Show_Balance_btn_Click);
            // 
            // AccountName_label
            // 
            this.AccountName_label.BackColor = System.Drawing.Color.White;
            this.Transition.SetDecoration(this.AccountName_label, Guna.UI2.AnimatorNS.DecorationType.None);
            this.AccountName_label.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AccountName_label.ForeColor = System.Drawing.Color.Gray;
            this.AccountName_label.Location = new System.Drawing.Point(72, 43);
            this.AccountName_label.Name = "AccountName_label";
            this.AccountName_label.Size = new System.Drawing.Size(356, 39);
            this.AccountName_label.TabIndex = 4;
            this.AccountName_label.Text = "Accoutn holder Name";
            this.AccountName_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.White;
            this.Transition.SetDecoration(this.label2, Guna.UI2.AnimatorNS.DecorationType.None);
            this.label2.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Silver;
            this.label2.Location = new System.Drawing.Point(68, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(283, 39);
            this.label2.TabIndex = 3;
            this.label2.Text = "From Account";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Transition
            // 
            this.Transition.AnimationType = Guna.UI2.AnimatorNS.AnimationType.ScaleAndRotate;
            this.Transition.Cursor = null;
            animation1.AnimateOnlyDifferences = true;
            animation1.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.BlindCoeff")));
            animation1.LeafCoeff = 0F;
            animation1.MaxTime = 1F;
            animation1.MinTime = 0F;
            animation1.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.MosaicCoeff")));
            animation1.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation1.MosaicShift")));
            animation1.MosaicSize = 0;
            animation1.Padding = new System.Windows.Forms.Padding(30);
            animation1.RotateCoeff = 0.5F;
            animation1.RotateLimit = 0.2F;
            animation1.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.ScaleCoeff")));
            animation1.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.SlideCoeff")));
            animation1.TimeCoeff = 0F;
            animation1.TransparencyCoeff = 0F;
            this.Transition.DefaultAnimation = animation1;
            // 
            // DragControl1
            // 
            this.DragControl1.ContainerControl = this;
            this.DragControl1.TargetControl = this.MainPanel;
            this.DragControl1.TransparentWhileDrag = true;
            this.DragControl1.UseTransparentDrag = true;
            // 
            // paysTableAdapter
            // 
            this.paysTableAdapter.ClearBeforeFill = true;
            // 
            // Pays_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1216, 811);
            this.Controls.Add(this.Markets_panel);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.MainPanel);
            this.Transition.SetDecoration(this, Guna.UI2.AnimatorNS.DecorationType.None);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Pays_Form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Pays Bills";
            this.Load += new System.EventHandler(this.Pays_Form_Load);
            this.MainPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Return_btn)).EndInit();
            this.panel1.ResumeLayout(false);
            this.Markets_panel.ResumeLayout(false);
            this.MainNetworkPanel.ResumeLayout(false);
            this.NetworkDatagridPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Net_BackBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Net_Upbtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.net_DownBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NetworkDatagrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.paysBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.onlineBankingSystemDBDataset1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox1)).EndInit();
            this.MainUniversityPanel.ResumeLayout(false);
            this.UniversityDatagridViewPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.UniversityBackBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Unversity_UpBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.University_DownBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.UniversityDatagridview)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.MainMarketPanel.ResumeLayout(false);
            this.Market_panel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            this.Markets_DataGrid_panel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Back_TOPanelBTN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Down_btn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Up_btn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Market_Datagridview)).EndInit();
            this.one_m.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2BorderlessForm CustomBorder;
        private Guna.UI2.WinForms.Guna2Panel MainPanel;
        private System.Windows.Forms.Panel panel1;
        private Guna.UI2.WinForms.Guna2Button Market_btn;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2PictureBox Return_btn;
        private Guna.UI2.WinForms.Guna2VSeparator Seprator1;
        private Guna.UI2.WinForms.Guna2Button University_btn;
        private Guna.UI2.WinForms.Guna2Button Networks_btn;
        private Guna.UI2.WinForms.Guna2VSeparator guna2VSeparator1;
        private Guna.UI2.WinForms.Guna2Panel Markets_panel;
        private Guna.UI2.WinForms.Guna2Transition Transition;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator1;
        private Guna.UI2.WinForms.Guna2Panel one_m;
        private System.Windows.Forms.Label AccountName_label;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2Button Show_Balance_btn;
        private Guna.UI2.WinForms.Guna2Panel Market_panel;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2ComboBox Markets_combbox;
        private Guna.UI2.WinForms.Guna2TextBox Amount_textBox;
        private Guna.UI2.WinForms.Guna2TextBox Comment_textBox;
        private Guna.UI2.WinForms.Guna2TextBox Comment_textBoxx;
        private Guna.UI2.WinForms.Guna2TextBox Invoice_textBox;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator2;
        private System.Windows.Forms.Label DateTime_label;
        private Guna.UI2.WinForms.Guna2DragControl DragControl1;
        private Guna.UI2.WinForms.Guna2Button Clear_btn;
        private Guna.UI2.WinForms.Guna2Button Pay_btn;
        private OnlineBankingSystemDBDataset onlineBankingSystemDBDataset1;
        private System.Windows.Forms.BindingSource paysBindingSource;
        private OnlineBankingSystemDBDatasetTableAdapters.PaysTableAdapter paysTableAdapter;
        private System.Windows.Forms.ToolTip toolTip1;
        private Guna.UI2.WinForms.Guna2Panel Markets_DataGrid_panel;
        private Guna.UI2.WinForms.Guna2CirclePictureBox Up_btn;
        private Guna.UI2.WinForms.Guna2Button save_btn;
        private Guna.UI2.WinForms.Guna2DataGridView Market_Datagridview;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn shopNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn invoiceNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn commentDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn userNameDataGridViewTextBoxColumn;
        private Guna.UI2.WinForms.Guna2CirclePictureBox Down_btn;
        private Guna.UI2.WinForms.Guna2Button Market_History_btn;
        private Guna.UI2.WinForms.Guna2CirclePictureBox Back_TOPanelBTN;
        private Guna.UI2.WinForms.Guna2Panel MainMarketPanel;
        private Guna.UI2.WinForms.Guna2Panel MainUniversityPanel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Guna.UI2.WinForms.Guna2ComboBox UniversityName_Combobox;
        private System.Windows.Forms.Label label4;
        private Guna.UI2.WinForms.Guna2Button University_historyBtn;
        private Guna.UI2.WinForms.Guna2Button University_ClearBtn;
        private Guna.UI2.WinForms.Guna2Button University_PayBtn;
        private Guna.UI2.WinForms.Guna2TextBox UniversityInvoice_textbox;
        private Guna.UI2.WinForms.Guna2TextBox UniversityComment_TextBox;
        private Guna.UI2.WinForms.Guna2TextBox University_AmountTextBox;
        private Guna.UI2.WinForms.Guna2Panel UniversityDatagridViewPanel;
        private Guna.UI2.WinForms.Guna2DataGridView UniversityDatagridview;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn shopNameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn invoiceNoDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn commentDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn userNameDataGridViewTextBoxColumn1;
        private Guna.UI2.WinForms.Guna2Button University_SaveBtn;
        private Guna.UI2.WinForms.Guna2CirclePictureBox Unversity_UpBtn;
        private Guna.UI2.WinForms.Guna2CirclePictureBox University_DownBtn;
        private Guna.UI2.WinForms.Guna2PictureBox UniversityBackBtn;
        private Guna.UI2.WinForms.Guna2Panel MainNetworkPanel;
        private Guna.UI2.WinForms.Guna2TextBox Net_InvoiceTextBox;
        private Guna.UI2.WinForms.Guna2TextBox Net_CommentTextBox;
        private Guna.UI2.WinForms.Guna2TextBox Net_AmountTextBox;
        private Guna.UI2.WinForms.Guna2Button Net_HistoryBtn;
        private Guna.UI2.WinForms.Guna2Button Net_ClearBtn;
        private Guna.UI2.WinForms.Guna2Button Net_PayBtn;
        private Guna.UI2.WinForms.Guna2ComboBox Net_Combobox;
        private System.Windows.Forms.Label label5;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox1;
        private Guna.UI2.WinForms.Guna2Panel NetworkDatagridPanel;
        private Guna.UI2.WinForms.Guna2PictureBox Net_BackBtn;
        private Guna.UI2.WinForms.Guna2Button Net_SaveBtn;
        private Guna.UI2.WinForms.Guna2CirclePictureBox Net_Upbtn;
        private Guna.UI2.WinForms.Guna2CirclePictureBox net_DownBtn;
        private Guna.UI2.WinForms.Guna2DataGridView NetworkDatagrid;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn shopNameDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn invoiceNoDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn commentDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn userNameDataGridViewTextBoxColumn2;
    }
}