﻿using System;
using System.Windows.Forms;

namespace OnlineBanking_System
{
    public partial class Account_Status : Form
    {
        public Account_Status()
        {
            InitializeComponent();
        }
        private string getName() 
        {
            return Start_Form.U_Name;

        }

        private void Account_Status_Load(object sender, EventArgs e)
        {
            AccountName_label.Text = getName();
        }

        private void Back_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Main_Form main = new Main_Form();
            main.ShowDialog();
        }
    }
}
