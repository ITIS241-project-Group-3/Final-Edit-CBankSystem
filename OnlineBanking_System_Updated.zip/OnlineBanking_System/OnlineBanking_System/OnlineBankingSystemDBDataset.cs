﻿namespace OnlineBanking_System
{


    partial class OnlineBankingSystemDBDataset
    {
    }
}

namespace OnlineBanking_System.OnlineBankingSystemDBDatasetTableAdapters {
    
    
    public partial class UsersTableAdapter {
    }
}
