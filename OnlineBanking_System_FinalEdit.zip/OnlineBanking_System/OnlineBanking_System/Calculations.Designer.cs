﻿
namespace OnlineBanking_System
{
    partial class Calculations
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Guna.UI2.AnimatorNS.Animation animation2 = new Guna.UI2.AnimatorNS.Animation();
            Guna.UI2.AnimatorNS.Animation animation1 = new Guna.UI2.AnimatorNS.Animation();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Calculations));
            this.DragControl = new Guna.UI2.WinForms.Guna2DragControl(this.components);
            this.BorderlessForm = new Guna.UI2.WinForms.Guna2BorderlessForm(this.components);
            this.Design_panel = new Guna.UI2.WinForms.Guna2Panel();
            this.Exp_btn = new Guna.UI2.WinForms.Guna2Button();
            this.EdgeDesign_Calculator = new Guna.UI2.WinForms.Guna2CircleButton();
            this.Edge_Design_Income = new Guna.UI2.WinForms.Guna2CircleButton();
            this.Income_Btn = new Guna.UI2.WinForms.Guna2Button();
            this.Calculator_Btn = new Guna.UI2.WinForms.Guna2Button();
            this.label4 = new System.Windows.Forms.Label();
            this.guna2PictureBox4 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.Calculator_panel = new Guna.UI2.WinForms.Guna2Panel();
            this.Operator_label = new System.Windows.Forms.Label();
            this.guna2GradientButton18 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.Result_TextBox = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2GradientButton7 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton17 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton8 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton1 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton10 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton16 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton9 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton2 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton11 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton15 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton4 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton3 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton12 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton14 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton5 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton6 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton13 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.Transition1 = new Guna.UI2.WinForms.Guna2Transition();
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.Back_btn = new Guna.UI2.WinForms.Guna2PictureBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.guna2PictureBox3 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.guna2PictureBox2 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.Advertise_1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.Calculator_Title_Label = new System.Windows.Forms.Label();
            this.Income_panel = new Guna.UI2.WinForms.Guna2Panel();
            this.Clear_Everythings_btn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.Total_Result_label = new System.Windows.Forms.Label();
            this.Total_Expenses = new System.Windows.Forms.Label();
            this.T_REvenue_Label = new System.Windows.Forms.Label();
            this.Icome_TExp_label = new System.Windows.Forms.Label();
            this.Icome_TRev_label = new System.Windows.Forms.Label();
            this.Income_label = new System.Windows.Forms.Label();
            this.GenerateIncome_btn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2Separator2 = new Guna.UI2.WinForms.Guna2Separator();
            this.guna2Separator1 = new Guna.UI2.WinForms.Guna2Separator();
            this.Clear_ExpBox_btn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.label9 = new System.Windows.Forms.Label();
            this.EnterExpense_btn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.label10 = new System.Windows.Forms.Label();
            this.Expense_textBox = new Guna.UI2.WinForms.Guna2TextBox();
            this.Expense_Combobox = new System.Windows.Forms.ComboBox();
            this.ClearRevenue_btn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.label8 = new System.Windows.Forms.Label();
            this.EnterRevenue_btn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.label7 = new System.Windows.Forms.Label();
            this.Revenue_textBox = new Guna.UI2.WinForms.Guna2TextBox();
            this.Revenue_Combobox = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Intro_Panel = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.Web_panel = new System.Windows.Forms.Panel();
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.label11 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.Count_ItemRevenue_Notif = new Guna.UI2.WinForms.Guna2NotificationPaint(this.components);
            this.Count_ItemExpenses_Notfi = new Guna.UI2.WinForms.Guna2NotificationPaint(this.components);
            this.Income_panel_Transition1 = new Guna.UI2.WinForms.Guna2Transition();
            this.Design_panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox4)).BeginInit();
            this.Calculator_panel.SuspendLayout();
            this.guna2Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Back_btn)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).BeginInit();
            this.Advertise_1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            this.Income_panel.SuspendLayout();
            this.Intro_Panel.SuspendLayout();
            this.Web_panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // DragControl
            // 
            this.DragControl.ContainerControl = this;
            this.DragControl.TargetControl = this;
            this.DragControl.TransparentWhileDrag = true;
            this.DragControl.UseTransparentDrag = true;
            // 
            // BorderlessForm
            // 
            this.BorderlessForm.AnimateWindow = true;
            this.BorderlessForm.BorderRadius = 50;
            this.BorderlessForm.ContainerControl = this;
            this.BorderlessForm.ShadowColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.BorderlessForm.TransparentWhileDrag = true;
            // 
            // Design_panel
            // 
            this.Design_panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.Design_panel.Controls.Add(this.Exp_btn);
            this.Design_panel.Controls.Add(this.EdgeDesign_Calculator);
            this.Design_panel.Controls.Add(this.Edge_Design_Income);
            this.Design_panel.Controls.Add(this.Income_Btn);
            this.Design_panel.Controls.Add(this.Calculator_Btn);
            this.Design_panel.Controls.Add(this.label4);
            this.Design_panel.Controls.Add(this.guna2PictureBox4);
            this.Income_panel_Transition1.SetDecoration(this.Design_panel, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.Design_panel, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Design_panel.Dock = System.Windows.Forms.DockStyle.Left;
            this.Design_panel.Location = new System.Drawing.Point(0, 0);
            this.Design_panel.Name = "Design_panel";
            this.Design_panel.ShadowDecoration.Parent = this.Design_panel;
            this.Design_panel.Size = new System.Drawing.Size(265, 772);
            this.Design_panel.TabIndex = 0;
            // 
            // Exp_btn
            // 
            this.Exp_btn.CheckedState.Parent = this.Exp_btn;
            this.Exp_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Exp_btn.CustomImages.Parent = this.Exp_btn;
            this.Income_panel_Transition1.SetDecoration(this.Exp_btn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.Exp_btn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Exp_btn.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.Exp_btn.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Exp_btn.ForeColor = System.Drawing.Color.White;
            this.Exp_btn.HoverState.Parent = this.Exp_btn;
            this.Exp_btn.Image = global::OnlineBanking_System.Properties.Resources.business_presentation;
            this.Exp_btn.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Exp_btn.ImageSize = new System.Drawing.Size(50, 50);
            this.Exp_btn.Location = new System.Drawing.Point(0, 280);
            this.Exp_btn.Name = "Exp_btn";
            this.Exp_btn.ShadowDecoration.Parent = this.Exp_btn;
            this.Exp_btn.Size = new System.Drawing.Size(259, 91);
            this.Exp_btn.TabIndex = 6;
            this.Exp_btn.Text = "Explanation";
            this.toolTip1.SetToolTip(this.Exp_btn, "Explanations youtube");
            this.Exp_btn.Click += new System.EventHandler(this.Exp_btn_Click);
            // 
            // EdgeDesign_Calculator
            // 
            this.EdgeDesign_Calculator.BackColor = System.Drawing.Color.Transparent;
            this.EdgeDesign_Calculator.BorderColor = System.Drawing.Color.White;
            this.EdgeDesign_Calculator.CheckedState.Parent = this.EdgeDesign_Calculator;
            this.EdgeDesign_Calculator.CustomImages.Parent = this.EdgeDesign_Calculator;
            this.Income_panel_Transition1.SetDecoration(this.EdgeDesign_Calculator, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.EdgeDesign_Calculator, Guna.UI2.AnimatorNS.DecorationType.None);
            this.EdgeDesign_Calculator.FillColor = System.Drawing.Color.White;
            this.EdgeDesign_Calculator.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.EdgeDesign_Calculator.ForeColor = System.Drawing.Color.White;
            this.EdgeDesign_Calculator.HoverState.BorderColor = System.Drawing.Color.White;
            this.EdgeDesign_Calculator.HoverState.FillColor = System.Drawing.Color.White;
            this.EdgeDesign_Calculator.HoverState.ForeColor = System.Drawing.Color.White;
            this.EdgeDesign_Calculator.HoverState.Parent = this.EdgeDesign_Calculator;
            this.EdgeDesign_Calculator.Location = new System.Drawing.Point(220, 377);
            this.EdgeDesign_Calculator.Name = "EdgeDesign_Calculator";
            this.EdgeDesign_Calculator.PressedColor = System.Drawing.Color.White;
            this.EdgeDesign_Calculator.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.EdgeDesign_Calculator.ShadowDecoration.Parent = this.EdgeDesign_Calculator;
            this.EdgeDesign_Calculator.Size = new System.Drawing.Size(90, 88);
            this.EdgeDesign_Calculator.TabIndex = 3;
            this.EdgeDesign_Calculator.UseTransparentBackground = true;
            this.EdgeDesign_Calculator.Visible = false;
            // 
            // Edge_Design_Income
            // 
            this.Edge_Design_Income.BackColor = System.Drawing.Color.Transparent;
            this.Edge_Design_Income.BorderColor = System.Drawing.Color.White;
            this.Edge_Design_Income.CheckedState.Parent = this.Edge_Design_Income;
            this.Edge_Design_Income.CustomImages.Parent = this.Edge_Design_Income;
            this.Income_panel_Transition1.SetDecoration(this.Edge_Design_Income, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.Edge_Design_Income, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Edge_Design_Income.FillColor = System.Drawing.Color.White;
            this.Edge_Design_Income.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Edge_Design_Income.ForeColor = System.Drawing.Color.White;
            this.Edge_Design_Income.HoverState.BorderColor = System.Drawing.Color.White;
            this.Edge_Design_Income.HoverState.FillColor = System.Drawing.Color.White;
            this.Edge_Design_Income.HoverState.ForeColor = System.Drawing.Color.White;
            this.Edge_Design_Income.HoverState.Parent = this.Edge_Design_Income;
            this.Edge_Design_Income.Location = new System.Drawing.Point(220, 481);
            this.Edge_Design_Income.Name = "Edge_Design_Income";
            this.Edge_Design_Income.PressedColor = System.Drawing.Color.White;
            this.Edge_Design_Income.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.Edge_Design_Income.ShadowDecoration.Parent = this.Edge_Design_Income;
            this.Edge_Design_Income.Size = new System.Drawing.Size(99, 85);
            this.Edge_Design_Income.TabIndex = 6;
            this.Edge_Design_Income.UseTransparentBackground = true;
            this.Edge_Design_Income.Visible = false;
            // 
            // Income_Btn
            // 
            this.Income_Btn.CheckedState.Parent = this.Income_Btn;
            this.Income_Btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Income_Btn.CustomImages.Parent = this.Income_Btn;
            this.Income_panel_Transition1.SetDecoration(this.Income_Btn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.Income_Btn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Income_Btn.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.Income_Btn.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Income_Btn.ForeColor = System.Drawing.Color.White;
            this.Income_Btn.HoverState.Parent = this.Income_Btn;
            this.Income_Btn.Image = global::OnlineBanking_System.Properties.Resources.growth;
            this.Income_Btn.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Income_Btn.ImageSize = new System.Drawing.Size(50, 50);
            this.Income_Btn.Location = new System.Drawing.Point(0, 477);
            this.Income_Btn.Name = "Income_Btn";
            this.Income_Btn.ShadowDecoration.Parent = this.Income_Btn;
            this.Income_Btn.Size = new System.Drawing.Size(259, 94);
            this.Income_Btn.TabIndex = 5;
            this.Income_Btn.Text = "Calculate Income";
            this.Income_Btn.TextOffset = new System.Drawing.Point(12, 0);
            this.toolTip1.SetToolTip(this.Income_Btn, "Income Calculator");
            this.Income_Btn.Click += new System.EventHandler(this.Income_Btn_Click);
            // 
            // Calculator_Btn
            // 
            this.Calculator_Btn.CheckedState.Parent = this.Calculator_Btn;
            this.Calculator_Btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Calculator_Btn.CustomImages.Parent = this.Calculator_Btn;
            this.Income_panel_Transition1.SetDecoration(this.Calculator_Btn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.Calculator_Btn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Calculator_Btn.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.Calculator_Btn.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Calculator_Btn.ForeColor = System.Drawing.Color.White;
            this.Calculator_Btn.HoverState.Parent = this.Calculator_Btn;
            this.Calculator_Btn.Image = global::OnlineBanking_System.Properties.Resources.calculator;
            this.Calculator_Btn.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Calculator_Btn.ImageSize = new System.Drawing.Size(50, 50);
            this.Calculator_Btn.Location = new System.Drawing.Point(3, 377);
            this.Calculator_Btn.Name = "Calculator_Btn";
            this.Calculator_Btn.ShadowDecoration.Parent = this.Calculator_Btn;
            this.Calculator_Btn.Size = new System.Drawing.Size(259, 91);
            this.Calculator_Btn.TabIndex = 4;
            this.Calculator_Btn.Text = "Calculator";
            this.toolTip1.SetToolTip(this.Calculator_Btn, "Open Calculator");
            this.Calculator_Btn.Click += new System.EventHandler(this.Calculator_Btn_Click);
            // 
            // label4
            // 
            this.Transition1.SetDecoration(this.label4, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Income_panel_Transition1.SetDecoration(this.label4, Guna.UI2.AnimatorNS.DecorationType.None);
            this.label4.Font = new System.Drawing.Font("Script MT Bold", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(12, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(216, 76);
            this.label4.TabIndex = 3;
            this.label4.Text = "Calculations";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // guna2PictureBox4
            // 
            this.guna2PictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.Income_panel_Transition1.SetDecoration(this.guna2PictureBox4, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.guna2PictureBox4, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2PictureBox4.Image = global::OnlineBanking_System.Properties.Resources.finance;
            this.guna2PictureBox4.Location = new System.Drawing.Point(62, 85);
            this.guna2PictureBox4.Name = "guna2PictureBox4";
            this.guna2PictureBox4.ShadowDecoration.Parent = this.guna2PictureBox4;
            this.guna2PictureBox4.Size = new System.Drawing.Size(178, 169);
            this.guna2PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox4.TabIndex = 3;
            this.guna2PictureBox4.TabStop = false;
            this.guna2PictureBox4.UseTransparentBackground = true;
            // 
            // Calculator_panel
            // 
            this.Calculator_panel.BackColor = System.Drawing.Color.Transparent;
            this.Calculator_panel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.Calculator_panel.BorderRadius = 50;
            this.Calculator_panel.BorderThickness = 3;
            this.Calculator_panel.Controls.Add(this.Operator_label);
            this.Calculator_panel.Controls.Add(this.guna2GradientButton18);
            this.Calculator_panel.Controls.Add(this.Result_TextBox);
            this.Calculator_panel.Controls.Add(this.guna2GradientButton7);
            this.Calculator_panel.Controls.Add(this.guna2GradientButton17);
            this.Calculator_panel.Controls.Add(this.guna2GradientButton8);
            this.Calculator_panel.Controls.Add(this.guna2GradientButton1);
            this.Calculator_panel.Controls.Add(this.guna2GradientButton10);
            this.Calculator_panel.Controls.Add(this.guna2GradientButton16);
            this.Calculator_panel.Controls.Add(this.guna2GradientButton9);
            this.Calculator_panel.Controls.Add(this.guna2GradientButton2);
            this.Calculator_panel.Controls.Add(this.guna2GradientButton11);
            this.Calculator_panel.Controls.Add(this.guna2GradientButton15);
            this.Calculator_panel.Controls.Add(this.guna2GradientButton4);
            this.Calculator_panel.Controls.Add(this.guna2GradientButton3);
            this.Calculator_panel.Controls.Add(this.guna2GradientButton12);
            this.Calculator_panel.Controls.Add(this.guna2GradientButton14);
            this.Calculator_panel.Controls.Add(this.guna2GradientButton5);
            this.Calculator_panel.Controls.Add(this.guna2GradientButton6);
            this.Calculator_panel.Controls.Add(this.guna2GradientButton13);
            this.Income_panel_Transition1.SetDecoration(this.Calculator_panel, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.Calculator_panel, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Calculator_panel.Location = new System.Drawing.Point(367, 168);
            this.Calculator_panel.Name = "Calculator_panel";
            this.Calculator_panel.ShadowDecoration.Parent = this.Calculator_panel;
            this.Calculator_panel.Size = new System.Drawing.Size(406, 523);
            this.Calculator_panel.TabIndex = 1;
            this.Calculator_panel.Visible = false;
            // 
            // Operator_label
            // 
            this.Operator_label.AutoSize = true;
            this.Transition1.SetDecoration(this.Operator_label, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Income_panel_Transition1.SetDecoration(this.Operator_label, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Operator_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Operator_label.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.Operator_label.Location = new System.Drawing.Point(55, 20);
            this.Operator_label.Name = "Operator_label";
            this.Operator_label.Size = new System.Drawing.Size(0, 20);
            this.Operator_label.TabIndex = 19;
            // 
            // guna2GradientButton18
            // 
            this.guna2GradientButton18.Animated = true;
            this.guna2GradientButton18.AutoRoundedCorners = true;
            this.guna2GradientButton18.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2GradientButton18.BorderRadius = 17;
            this.guna2GradientButton18.CheckedState.Parent = this.guna2GradientButton18;
            this.guna2GradientButton18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientButton18.CustomImages.Parent = this.guna2GradientButton18;
            this.Income_panel_Transition1.SetDecoration(this.guna2GradientButton18, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.guna2GradientButton18, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2GradientButton18.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.guna2GradientButton18.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton18.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton18.HoverState.Parent = this.guna2GradientButton18;
            this.guna2GradientButton18.Location = new System.Drawing.Point(277, 426);
            this.guna2GradientButton18.Name = "guna2GradientButton18";
            this.guna2GradientButton18.ShadowDecoration.Parent = this.guna2GradientButton18;
            this.guna2GradientButton18.Size = new System.Drawing.Size(104, 37);
            this.guna2GradientButton18.TabIndex = 18;
            this.guna2GradientButton18.Text = "Close";
            this.guna2GradientButton18.Click += new System.EventHandler(this.guna2GradientButton18_Click);
            // 
            // Result_TextBox
            // 
            this.Result_TextBox.Animated = true;
            this.Result_TextBox.AutoRoundedCorners = true;
            this.Result_TextBox.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(165)))));
            this.Result_TextBox.BorderRadius = 22;
            this.Result_TextBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Income_panel_Transition1.SetDecoration(this.Result_TextBox, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.Result_TextBox, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Result_TextBox.DefaultText = "";
            this.Result_TextBox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Result_TextBox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Result_TextBox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Result_TextBox.DisabledState.Parent = this.Result_TextBox;
            this.Result_TextBox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Result_TextBox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Result_TextBox.FocusedState.Parent = this.Result_TextBox;
            this.Result_TextBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Result_TextBox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Result_TextBox.HoverState.Parent = this.Result_TextBox;
            this.Result_TextBox.Location = new System.Drawing.Point(42, 55);
            this.Result_TextBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Result_TextBox.Name = "Result_TextBox";
            this.Result_TextBox.PasswordChar = '\0';
            this.Result_TextBox.PlaceholderText = "";
            this.Result_TextBox.SelectedText = "";
            this.Result_TextBox.ShadowDecoration.Parent = this.Result_TextBox;
            this.Result_TextBox.Size = new System.Drawing.Size(325, 46);
            this.Result_TextBox.TabIndex = 1;
            // 
            // guna2GradientButton7
            // 
            this.guna2GradientButton7.Animated = true;
            this.guna2GradientButton7.AutoRoundedCorners = true;
            this.guna2GradientButton7.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2GradientButton7.BorderRadius = 17;
            this.guna2GradientButton7.CheckedState.Parent = this.guna2GradientButton7;
            this.guna2GradientButton7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientButton7.CustomImages.Parent = this.guna2GradientButton7;
            this.Income_panel_Transition1.SetDecoration(this.guna2GradientButton7, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.guna2GradientButton7, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2GradientButton7.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.guna2GradientButton7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2GradientButton7.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton7.HoverState.Parent = this.guna2GradientButton7;
            this.guna2GradientButton7.Location = new System.Drawing.Point(277, 313);
            this.guna2GradientButton7.Name = "guna2GradientButton7";
            this.guna2GradientButton7.ShadowDecoration.Parent = this.guna2GradientButton7;
            this.guna2GradientButton7.Size = new System.Drawing.Size(104, 37);
            this.guna2GradientButton7.TabIndex = 9;
            this.guna2GradientButton7.Text = "9";
            this.guna2GradientButton7.Click += new System.EventHandler(this.Button_click);
            // 
            // guna2GradientButton17
            // 
            this.guna2GradientButton17.Animated = true;
            this.guna2GradientButton17.AutoRoundedCorners = true;
            this.guna2GradientButton17.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2GradientButton17.BorderRadius = 17;
            this.guna2GradientButton17.CheckedState.Parent = this.guna2GradientButton17;
            this.guna2GradientButton17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientButton17.CustomImages.Parent = this.guna2GradientButton17;
            this.Income_panel_Transition1.SetDecoration(this.guna2GradientButton17, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.guna2GradientButton17, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2GradientButton17.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.guna2GradientButton17.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton17.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton17.HoverState.Parent = this.guna2GradientButton17;
            this.guna2GradientButton17.Location = new System.Drawing.Point(27, 426);
            this.guna2GradientButton17.Name = "guna2GradientButton17";
            this.guna2GradientButton17.ShadowDecoration.Parent = this.guna2GradientButton17;
            this.guna2GradientButton17.Size = new System.Drawing.Size(104, 37);
            this.guna2GradientButton17.TabIndex = 17;
            this.guna2GradientButton17.Text = "C";
            this.guna2GradientButton17.Click += new System.EventHandler(this.guna2GradientButton17_Click);
            // 
            // guna2GradientButton8
            // 
            this.guna2GradientButton8.Animated = true;
            this.guna2GradientButton8.AutoRoundedCorners = true;
            this.guna2GradientButton8.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2GradientButton8.BorderRadius = 17;
            this.guna2GradientButton8.CheckedState.Parent = this.guna2GradientButton8;
            this.guna2GradientButton8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientButton8.CustomImages.Parent = this.guna2GradientButton8;
            this.Income_panel_Transition1.SetDecoration(this.guna2GradientButton8, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.guna2GradientButton8, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2GradientButton8.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.guna2GradientButton8.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2GradientButton8.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton8.HoverState.Parent = this.guna2GradientButton8;
            this.guna2GradientButton8.Location = new System.Drawing.Point(148, 313);
            this.guna2GradientButton8.Name = "guna2GradientButton8";
            this.guna2GradientButton8.ShadowDecoration.Parent = this.guna2GradientButton8;
            this.guna2GradientButton8.Size = new System.Drawing.Size(104, 37);
            this.guna2GradientButton8.TabIndex = 8;
            this.guna2GradientButton8.Text = "8";
            this.guna2GradientButton8.Click += new System.EventHandler(this.Button_click);
            // 
            // guna2GradientButton1
            // 
            this.guna2GradientButton1.Animated = true;
            this.guna2GradientButton1.AutoRoundedCorners = true;
            this.guna2GradientButton1.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2GradientButton1.BorderRadius = 17;
            this.guna2GradientButton1.CheckedState.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientButton1.CustomImages.Parent = this.guna2GradientButton1;
            this.Income_panel_Transition1.SetDecoration(this.guna2GradientButton1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.guna2GradientButton1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2GradientButton1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.guna2GradientButton1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2GradientButton1.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton1.HoverState.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Location = new System.Drawing.Point(27, 203);
            this.guna2GradientButton1.Name = "guna2GradientButton1";
            this.guna2GradientButton1.ShadowDecoration.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Size = new System.Drawing.Size(104, 37);
            this.guna2GradientButton1.TabIndex = 1;
            this.guna2GradientButton1.Text = "1";
            this.guna2GradientButton1.Click += new System.EventHandler(this.Button_click);
            // 
            // guna2GradientButton10
            // 
            this.guna2GradientButton10.Animated = true;
            this.guna2GradientButton10.AutoRoundedCorners = true;
            this.guna2GradientButton10.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2GradientButton10.BorderRadius = 17;
            this.guna2GradientButton10.CheckedState.Parent = this.guna2GradientButton10;
            this.guna2GradientButton10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientButton10.CustomImages.Parent = this.guna2GradientButton10;
            this.Income_panel_Transition1.SetDecoration(this.guna2GradientButton10, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.guna2GradientButton10, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2GradientButton10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.guna2GradientButton10.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2GradientButton10.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton10.HoverState.Parent = this.guna2GradientButton10;
            this.guna2GradientButton10.Location = new System.Drawing.Point(148, 369);
            this.guna2GradientButton10.Name = "guna2GradientButton10";
            this.guna2GradientButton10.ShadowDecoration.Parent = this.guna2GradientButton10;
            this.guna2GradientButton10.Size = new System.Drawing.Size(104, 37);
            this.guna2GradientButton10.TabIndex = 10;
            this.guna2GradientButton10.Text = "0";
            this.guna2GradientButton10.Click += new System.EventHandler(this.Button_click);
            // 
            // guna2GradientButton16
            // 
            this.guna2GradientButton16.Animated = true;
            this.guna2GradientButton16.AutoRoundedCorners = true;
            this.guna2GradientButton16.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2GradientButton16.BorderRadius = 17;
            this.guna2GradientButton16.CheckedState.Parent = this.guna2GradientButton16;
            this.guna2GradientButton16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientButton16.CustomImages.Parent = this.guna2GradientButton16;
            this.Income_panel_Transition1.SetDecoration(this.guna2GradientButton16, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.guna2GradientButton16, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2GradientButton16.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.guna2GradientButton16.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton16.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton16.HoverState.Parent = this.guna2GradientButton16;
            this.guna2GradientButton16.Location = new System.Drawing.Point(28, 369);
            this.guna2GradientButton16.Name = "guna2GradientButton16";
            this.guna2GradientButton16.ShadowDecoration.Parent = this.guna2GradientButton16;
            this.guna2GradientButton16.Size = new System.Drawing.Size(104, 37);
            this.guna2GradientButton16.TabIndex = 16;
            this.guna2GradientButton16.Text = ".";
            this.guna2GradientButton16.Click += new System.EventHandler(this.Button_click);
            // 
            // guna2GradientButton9
            // 
            this.guna2GradientButton9.Animated = true;
            this.guna2GradientButton9.AutoRoundedCorners = true;
            this.guna2GradientButton9.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2GradientButton9.BorderRadius = 17;
            this.guna2GradientButton9.CheckedState.Parent = this.guna2GradientButton9;
            this.guna2GradientButton9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientButton9.CustomImages.Parent = this.guna2GradientButton9;
            this.Income_panel_Transition1.SetDecoration(this.guna2GradientButton9, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.guna2GradientButton9, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2GradientButton9.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.guna2GradientButton9.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2GradientButton9.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton9.HoverState.Parent = this.guna2GradientButton9;
            this.guna2GradientButton9.Location = new System.Drawing.Point(27, 313);
            this.guna2GradientButton9.Name = "guna2GradientButton9";
            this.guna2GradientButton9.ShadowDecoration.Parent = this.guna2GradientButton9;
            this.guna2GradientButton9.Size = new System.Drawing.Size(104, 37);
            this.guna2GradientButton9.TabIndex = 7;
            this.guna2GradientButton9.Text = "7";
            this.guna2GradientButton9.Click += new System.EventHandler(this.Button_click);
            // 
            // guna2GradientButton2
            // 
            this.guna2GradientButton2.Animated = true;
            this.guna2GradientButton2.AutoRoundedCorners = true;
            this.guna2GradientButton2.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2GradientButton2.BorderRadius = 17;
            this.guna2GradientButton2.CheckedState.Parent = this.guna2GradientButton2;
            this.guna2GradientButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientButton2.CustomImages.Parent = this.guna2GradientButton2;
            this.Income_panel_Transition1.SetDecoration(this.guna2GradientButton2, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.guna2GradientButton2, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2GradientButton2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.guna2GradientButton2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2GradientButton2.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton2.HoverState.Parent = this.guna2GradientButton2;
            this.guna2GradientButton2.Location = new System.Drawing.Point(148, 203);
            this.guna2GradientButton2.Name = "guna2GradientButton2";
            this.guna2GradientButton2.ShadowDecoration.Parent = this.guna2GradientButton2;
            this.guna2GradientButton2.Size = new System.Drawing.Size(104, 37);
            this.guna2GradientButton2.TabIndex = 2;
            this.guna2GradientButton2.Text = "2";
            this.guna2GradientButton2.Click += new System.EventHandler(this.Button_click);
            // 
            // guna2GradientButton11
            // 
            this.guna2GradientButton11.Animated = true;
            this.guna2GradientButton11.AutoRoundedCorners = true;
            this.guna2GradientButton11.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2GradientButton11.BorderRadius = 17;
            this.guna2GradientButton11.CheckedState.Parent = this.guna2GradientButton11;
            this.guna2GradientButton11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientButton11.CustomImages.Parent = this.guna2GradientButton11;
            this.Income_panel_Transition1.SetDecoration(this.guna2GradientButton11, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.guna2GradientButton11, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2GradientButton11.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.guna2GradientButton11.Font = new System.Drawing.Font("Segoe UI Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2GradientButton11.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton11.HoverState.Parent = this.guna2GradientButton11;
            this.guna2GradientButton11.Location = new System.Drawing.Point(27, 146);
            this.guna2GradientButton11.Name = "guna2GradientButton11";
            this.guna2GradientButton11.ShadowDecoration.Parent = this.guna2GradientButton11;
            this.guna2GradientButton11.Size = new System.Drawing.Size(104, 37);
            this.guna2GradientButton11.TabIndex = 11;
            this.guna2GradientButton11.Text = "+";
            this.guna2GradientButton11.Click += new System.EventHandler(this.Operations_Calcu);
            // 
            // guna2GradientButton15
            // 
            this.guna2GradientButton15.Animated = true;
            this.guna2GradientButton15.AutoRoundedCorners = true;
            this.guna2GradientButton15.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2GradientButton15.BorderRadius = 17;
            this.guna2GradientButton15.CheckedState.Parent = this.guna2GradientButton15;
            this.guna2GradientButton15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientButton15.CustomImages.Parent = this.guna2GradientButton15;
            this.Income_panel_Transition1.SetDecoration(this.guna2GradientButton15, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.guna2GradientButton15, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2GradientButton15.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.guna2GradientButton15.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton15.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton15.HoverState.Parent = this.guna2GradientButton15;
            this.guna2GradientButton15.Location = new System.Drawing.Point(148, 426);
            this.guna2GradientButton15.Name = "guna2GradientButton15";
            this.guna2GradientButton15.ShadowDecoration.Parent = this.guna2GradientButton15;
            this.guna2GradientButton15.Size = new System.Drawing.Size(104, 37);
            this.guna2GradientButton15.TabIndex = 15;
            this.guna2GradientButton15.Text = "=";
            this.guna2GradientButton15.Click += new System.EventHandler(this.guna2GradientButton15_Click);
            // 
            // guna2GradientButton4
            // 
            this.guna2GradientButton4.Animated = true;
            this.guna2GradientButton4.AutoRoundedCorners = true;
            this.guna2GradientButton4.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2GradientButton4.BorderRadius = 17;
            this.guna2GradientButton4.CheckedState.Parent = this.guna2GradientButton4;
            this.guna2GradientButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientButton4.CustomImages.Parent = this.guna2GradientButton4;
            this.Income_panel_Transition1.SetDecoration(this.guna2GradientButton4, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.guna2GradientButton4, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2GradientButton4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.guna2GradientButton4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton4.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton4.HoverState.Parent = this.guna2GradientButton4;
            this.guna2GradientButton4.Location = new System.Drawing.Point(277, 260);
            this.guna2GradientButton4.Name = "guna2GradientButton4";
            this.guna2GradientButton4.ShadowDecoration.Parent = this.guna2GradientButton4;
            this.guna2GradientButton4.Size = new System.Drawing.Size(104, 37);
            this.guna2GradientButton4.TabIndex = 6;
            this.guna2GradientButton4.Text = "6";
            this.guna2GradientButton4.Click += new System.EventHandler(this.Button_click);
            // 
            // guna2GradientButton3
            // 
            this.guna2GradientButton3.Animated = true;
            this.guna2GradientButton3.AutoRoundedCorners = true;
            this.guna2GradientButton3.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2GradientButton3.BorderRadius = 17;
            this.guna2GradientButton3.CheckedState.Parent = this.guna2GradientButton3;
            this.guna2GradientButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientButton3.CustomImages.Parent = this.guna2GradientButton3;
            this.Income_panel_Transition1.SetDecoration(this.guna2GradientButton3, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.guna2GradientButton3, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2GradientButton3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.guna2GradientButton3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2GradientButton3.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton3.HoverState.Parent = this.guna2GradientButton3;
            this.guna2GradientButton3.Location = new System.Drawing.Point(277, 203);
            this.guna2GradientButton3.Name = "guna2GradientButton3";
            this.guna2GradientButton3.ShadowDecoration.Parent = this.guna2GradientButton3;
            this.guna2GradientButton3.Size = new System.Drawing.Size(104, 37);
            this.guna2GradientButton3.TabIndex = 3;
            this.guna2GradientButton3.Text = "3";
            this.guna2GradientButton3.Click += new System.EventHandler(this.Button_click);
            // 
            // guna2GradientButton12
            // 
            this.guna2GradientButton12.Animated = true;
            this.guna2GradientButton12.AutoRoundedCorners = true;
            this.guna2GradientButton12.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2GradientButton12.BorderRadius = 17;
            this.guna2GradientButton12.CheckedState.Parent = this.guna2GradientButton12;
            this.guna2GradientButton12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientButton12.CustomImages.Parent = this.guna2GradientButton12;
            this.Income_panel_Transition1.SetDecoration(this.guna2GradientButton12, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.guna2GradientButton12, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2GradientButton12.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.guna2GradientButton12.Font = new System.Drawing.Font("Segoe UI Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2GradientButton12.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton12.HoverState.Parent = this.guna2GradientButton12;
            this.guna2GradientButton12.Location = new System.Drawing.Point(148, 146);
            this.guna2GradientButton12.Name = "guna2GradientButton12";
            this.guna2GradientButton12.ShadowDecoration.Parent = this.guna2GradientButton12;
            this.guna2GradientButton12.Size = new System.Drawing.Size(104, 37);
            this.guna2GradientButton12.TabIndex = 12;
            this.guna2GradientButton12.Text = "-";
            this.guna2GradientButton12.Click += new System.EventHandler(this.Operations_Calcu);
            // 
            // guna2GradientButton14
            // 
            this.guna2GradientButton14.Animated = true;
            this.guna2GradientButton14.AutoRoundedCorners = true;
            this.guna2GradientButton14.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2GradientButton14.BorderRadius = 17;
            this.guna2GradientButton14.CheckedState.Parent = this.guna2GradientButton14;
            this.guna2GradientButton14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientButton14.CustomImages.Parent = this.guna2GradientButton14;
            this.Income_panel_Transition1.SetDecoration(this.guna2GradientButton14, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.guna2GradientButton14, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2GradientButton14.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.guna2GradientButton14.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton14.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton14.HoverState.Parent = this.guna2GradientButton14;
            this.guna2GradientButton14.Location = new System.Drawing.Point(277, 369);
            this.guna2GradientButton14.Name = "guna2GradientButton14";
            this.guna2GradientButton14.ShadowDecoration.Parent = this.guna2GradientButton14;
            this.guna2GradientButton14.Size = new System.Drawing.Size(104, 37);
            this.guna2GradientButton14.TabIndex = 14;
            this.guna2GradientButton14.Text = "/";
            this.guna2GradientButton14.Click += new System.EventHandler(this.Operations_Calcu);
            // 
            // guna2GradientButton5
            // 
            this.guna2GradientButton5.Animated = true;
            this.guna2GradientButton5.AutoRoundedCorners = true;
            this.guna2GradientButton5.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2GradientButton5.BorderRadius = 17;
            this.guna2GradientButton5.CheckedState.Parent = this.guna2GradientButton5;
            this.guna2GradientButton5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientButton5.CustomImages.Parent = this.guna2GradientButton5;
            this.Income_panel_Transition1.SetDecoration(this.guna2GradientButton5, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.guna2GradientButton5, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2GradientButton5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.guna2GradientButton5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2GradientButton5.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton5.HoverState.Parent = this.guna2GradientButton5;
            this.guna2GradientButton5.Location = new System.Drawing.Point(148, 260);
            this.guna2GradientButton5.Name = "guna2GradientButton5";
            this.guna2GradientButton5.ShadowDecoration.Parent = this.guna2GradientButton5;
            this.guna2GradientButton5.Size = new System.Drawing.Size(104, 37);
            this.guna2GradientButton5.TabIndex = 5;
            this.guna2GradientButton5.Text = "5";
            this.guna2GradientButton5.Click += new System.EventHandler(this.Button_click);
            // 
            // guna2GradientButton6
            // 
            this.guna2GradientButton6.Animated = true;
            this.guna2GradientButton6.AutoRoundedCorners = true;
            this.guna2GradientButton6.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2GradientButton6.BorderRadius = 17;
            this.guna2GradientButton6.CheckedState.Parent = this.guna2GradientButton6;
            this.guna2GradientButton6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientButton6.CustomImages.Parent = this.guna2GradientButton6;
            this.Income_panel_Transition1.SetDecoration(this.guna2GradientButton6, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.guna2GradientButton6, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2GradientButton6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.guna2GradientButton6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2GradientButton6.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton6.HoverState.Parent = this.guna2GradientButton6;
            this.guna2GradientButton6.Location = new System.Drawing.Point(27, 260);
            this.guna2GradientButton6.Name = "guna2GradientButton6";
            this.guna2GradientButton6.ShadowDecoration.Parent = this.guna2GradientButton6;
            this.guna2GradientButton6.Size = new System.Drawing.Size(104, 37);
            this.guna2GradientButton6.TabIndex = 4;
            this.guna2GradientButton6.Text = "4";
            this.guna2GradientButton6.Click += new System.EventHandler(this.Button_click);
            // 
            // guna2GradientButton13
            // 
            this.guna2GradientButton13.Animated = true;
            this.guna2GradientButton13.AutoRoundedCorners = true;
            this.guna2GradientButton13.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2GradientButton13.BorderRadius = 17;
            this.guna2GradientButton13.CheckedState.Parent = this.guna2GradientButton13;
            this.guna2GradientButton13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientButton13.CustomImages.Parent = this.guna2GradientButton13;
            this.Income_panel_Transition1.SetDecoration(this.guna2GradientButton13, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.guna2GradientButton13, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2GradientButton13.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.guna2GradientButton13.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton13.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton13.HoverState.Parent = this.guna2GradientButton13;
            this.guna2GradientButton13.Location = new System.Drawing.Point(277, 146);
            this.guna2GradientButton13.Name = "guna2GradientButton13";
            this.guna2GradientButton13.ShadowDecoration.Parent = this.guna2GradientButton13;
            this.guna2GradientButton13.Size = new System.Drawing.Size(104, 37);
            this.guna2GradientButton13.TabIndex = 13;
            this.guna2GradientButton13.Text = "X";
            this.guna2GradientButton13.Click += new System.EventHandler(this.Operations_Calcu);
            // 
            // Transition1
            // 
            this.Transition1.AnimationType = Guna.UI2.AnimatorNS.AnimationType.ScaleAndRotate;
            this.Transition1.Cursor = null;
            animation2.AnimateOnlyDifferences = true;
            animation2.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation2.BlindCoeff")));
            animation2.LeafCoeff = 0F;
            animation2.MaxTime = 1F;
            animation2.MinTime = 0F;
            animation2.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation2.MosaicCoeff")));
            animation2.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation2.MosaicShift")));
            animation2.MosaicSize = 0;
            animation2.Padding = new System.Windows.Forms.Padding(30);
            animation2.RotateCoeff = 0.5F;
            animation2.RotateLimit = 0.2F;
            animation2.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation2.ScaleCoeff")));
            animation2.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation2.SlideCoeff")));
            animation2.TimeCoeff = 0F;
            animation2.TransparencyCoeff = 0F;
            this.Transition1.DefaultAnimation = animation2;
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(165)))));
            this.guna2Panel1.Controls.Add(this.Back_btn);
            this.guna2Panel1.Controls.Add(this.groupBox2);
            this.guna2Panel1.Controls.Add(this.groupBox1);
            this.guna2Panel1.Controls.Add(this.Advertise_1);
            this.Income_panel_Transition1.SetDecoration(this.guna2Panel1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.guna2Panel1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2Panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.guna2Panel1.Location = new System.Drawing.Point(888, 0);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.ShadowDecoration.Parent = this.guna2Panel1;
            this.guna2Panel1.Size = new System.Drawing.Size(312, 772);
            this.guna2Panel1.TabIndex = 1;
            // 
            // Back_btn
            // 
            this.Back_btn.BackColor = System.Drawing.Color.Transparent;
            this.Back_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Income_panel_Transition1.SetDecoration(this.Back_btn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.Back_btn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Back_btn.Image = global::OnlineBanking_System.Properties.Resources.back;
            this.Back_btn.Location = new System.Drawing.Point(238, 9);
            this.Back_btn.Name = "Back_btn";
            this.Back_btn.ShadowDecoration.Parent = this.Back_btn;
            this.Back_btn.Size = new System.Drawing.Size(53, 46);
            this.Back_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Back_btn.TabIndex = 4;
            this.Back_btn.TabStop = false;
            this.toolTip1.SetToolTip(this.Back_btn, "Return to main ");
            this.Back_btn.UseTransparentBackground = true;
            this.Back_btn.Click += new System.EventHandler(this.Back_btn_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.guna2PictureBox3);
            this.Income_panel_Transition1.SetDecoration(this.groupBox2, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.groupBox2, Guna.UI2.AnimatorNS.DecorationType.None);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(29, 550);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(271, 191);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Coming Soon !!!!";
            // 
            // label3
            // 
            this.Transition1.SetDecoration(this.label3, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Income_panel_Transition1.SetDecoration(this.label3, Guna.UI2.AnimatorNS.DecorationType.None);
            this.label3.Location = new System.Drawing.Point(44, 152);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(179, 36);
            this.label3.TabIndex = 1;
            this.label3.Text = "Programming Certifcate";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // guna2PictureBox3
            // 
            this.guna2PictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.Income_panel_Transition1.SetDecoration(this.guna2PictureBox3, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.guna2PictureBox3, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2PictureBox3.Image = global::OnlineBanking_System.Properties.Resources.certification;
            this.guna2PictureBox3.Location = new System.Drawing.Point(27, 21);
            this.guna2PictureBox3.Name = "guna2PictureBox3";
            this.guna2PictureBox3.ShadowDecoration.Parent = this.guna2PictureBox3;
            this.guna2PictureBox3.Size = new System.Drawing.Size(207, 139);
            this.guna2PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox3.TabIndex = 0;
            this.guna2PictureBox3.TabStop = false;
            this.guna2PictureBox3.UseTransparentBackground = true;
            this.guna2PictureBox3.MouseHover += new System.EventHandler(this.guna2PictureBox3_MouseHover);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.guna2PictureBox2);
            this.Income_panel_Transition1.SetDecoration(this.groupBox1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.groupBox1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(29, 309);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(271, 191);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Coming Soon !!!!";
            // 
            // label2
            // 
            this.Transition1.SetDecoration(this.label2, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Income_panel_Transition1.SetDecoration(this.label2, Guna.UI2.AnimatorNS.DecorationType.None);
            this.label2.Location = new System.Drawing.Point(44, 152);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(179, 36);
            this.label2.TabIndex = 1;
            this.label2.Text = "Managmenet Certifcate";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // guna2PictureBox2
            // 
            this.guna2PictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.Income_panel_Transition1.SetDecoration(this.guna2PictureBox2, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.guna2PictureBox2, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2PictureBox2.Image = global::OnlineBanking_System.Properties.Resources.diploma;
            this.guna2PictureBox2.Location = new System.Drawing.Point(27, 21);
            this.guna2PictureBox2.Name = "guna2PictureBox2";
            this.guna2PictureBox2.ShadowDecoration.Parent = this.guna2PictureBox2;
            this.guna2PictureBox2.Size = new System.Drawing.Size(207, 139);
            this.guna2PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox2.TabIndex = 0;
            this.guna2PictureBox2.TabStop = false;
            this.guna2PictureBox2.UseTransparentBackground = true;
            this.guna2PictureBox2.MouseHover += new System.EventHandler(this.guna2PictureBox2_MouseHover);
            // 
            // Advertise_1
            // 
            this.Advertise_1.Controls.Add(this.label1);
            this.Advertise_1.Controls.Add(this.guna2PictureBox1);
            this.Income_panel_Transition1.SetDecoration(this.Advertise_1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.Advertise_1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Advertise_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Advertise_1.ForeColor = System.Drawing.Color.White;
            this.Advertise_1.Location = new System.Drawing.Point(29, 66);
            this.Advertise_1.Name = "Advertise_1";
            this.Advertise_1.Size = new System.Drawing.Size(271, 191);
            this.Advertise_1.TabIndex = 0;
            this.Advertise_1.TabStop = false;
            this.Advertise_1.Text = "Coming Soon !!!!";
            // 
            // label1
            // 
            this.Transition1.SetDecoration(this.label1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Income_panel_Transition1.SetDecoration(this.label1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.label1.Location = new System.Drawing.Point(44, 152);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(179, 36);
            this.label1.TabIndex = 1;
            this.label1.Text = "Bankaing Certifcate";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.Income_panel_Transition1.SetDecoration(this.guna2PictureBox1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.guna2PictureBox1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2PictureBox1.Image = global::OnlineBanking_System.Properties.Resources.certificate;
            this.guna2PictureBox1.Location = new System.Drawing.Point(27, 33);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.ShadowDecoration.Parent = this.guna2PictureBox1;
            this.guna2PictureBox1.Size = new System.Drawing.Size(207, 139);
            this.guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox1.TabIndex = 0;
            this.guna2PictureBox1.TabStop = false;
            this.guna2PictureBox1.UseTransparentBackground = true;
            this.guna2PictureBox1.MouseHover += new System.EventHandler(this.guna2PictureBox1_MouseHover);
            // 
            // Calculator_Title_Label
            // 
            this.Transition1.SetDecoration(this.Calculator_Title_Label, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Income_panel_Transition1.SetDecoration(this.Calculator_Title_Label, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Calculator_Title_Label.Font = new System.Drawing.Font("Script MT Bold", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Calculator_Title_Label.Location = new System.Drawing.Point(388, 57);
            this.Calculator_Title_Label.Name = "Calculator_Title_Label";
            this.Calculator_Title_Label.Size = new System.Drawing.Size(374, 76);
            this.Calculator_Title_Label.TabIndex = 2;
            this.Calculator_Title_Label.Text = "Simple Calculator";
            this.Calculator_Title_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Calculator_Title_Label.Visible = false;
            // 
            // Income_panel
            // 
            this.Income_panel.BackColor = System.Drawing.Color.Transparent;
            this.Income_panel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.Income_panel.BorderRadius = 50;
            this.Income_panel.BorderThickness = 3;
            this.Income_panel.Controls.Add(this.Clear_Everythings_btn);
            this.Income_panel.Controls.Add(this.Total_Result_label);
            this.Income_panel.Controls.Add(this.Total_Expenses);
            this.Income_panel.Controls.Add(this.T_REvenue_Label);
            this.Income_panel.Controls.Add(this.Icome_TExp_label);
            this.Income_panel.Controls.Add(this.Icome_TRev_label);
            this.Income_panel.Controls.Add(this.Income_label);
            this.Income_panel.Controls.Add(this.GenerateIncome_btn);
            this.Income_panel.Controls.Add(this.guna2Separator2);
            this.Income_panel.Controls.Add(this.guna2Separator1);
            this.Income_panel.Controls.Add(this.Clear_ExpBox_btn);
            this.Income_panel.Controls.Add(this.label9);
            this.Income_panel.Controls.Add(this.EnterExpense_btn);
            this.Income_panel.Controls.Add(this.label10);
            this.Income_panel.Controls.Add(this.Expense_textBox);
            this.Income_panel.Controls.Add(this.Expense_Combobox);
            this.Income_panel.Controls.Add(this.ClearRevenue_btn);
            this.Income_panel.Controls.Add(this.label8);
            this.Income_panel.Controls.Add(this.EnterRevenue_btn);
            this.Income_panel.Controls.Add(this.label7);
            this.Income_panel.Controls.Add(this.Revenue_textBox);
            this.Income_panel.Controls.Add(this.Revenue_Combobox);
            this.Income_panel.Controls.Add(this.label6);
            this.Income_panel.Controls.Add(this.label5);
            this.Income_panel_Transition1.SetDecoration(this.Income_panel, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.Income_panel, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Income_panel.Location = new System.Drawing.Point(271, 12);
            this.Income_panel.Name = "Income_panel";
            this.Income_panel.ShadowDecoration.Parent = this.Income_panel;
            this.Income_panel.Size = new System.Drawing.Size(611, 760);
            this.Income_panel.TabIndex = 20;
            this.Income_panel.Visible = false;
            // 
            // Clear_Everythings_btn
            // 
            this.Clear_Everythings_btn.Animated = true;
            this.Clear_Everythings_btn.AutoRoundedCorners = true;
            this.Clear_Everythings_btn.BorderRadius = 13;
            this.Clear_Everythings_btn.CheckedState.Parent = this.Clear_Everythings_btn;
            this.Clear_Everythings_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Clear_Everythings_btn.CustomImages.Parent = this.Clear_Everythings_btn;
            this.Income_panel_Transition1.SetDecoration(this.Clear_Everythings_btn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.Clear_Everythings_btn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Clear_Everythings_btn.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Clear_Everythings_btn.ForeColor = System.Drawing.Color.White;
            this.Clear_Everythings_btn.HoverState.Parent = this.Clear_Everythings_btn;
            this.Clear_Everythings_btn.Location = new System.Drawing.Point(311, 533);
            this.Clear_Everythings_btn.Name = "Clear_Everythings_btn";
            this.Clear_Everythings_btn.ShadowDecoration.Parent = this.Clear_Everythings_btn;
            this.Clear_Everythings_btn.Size = new System.Drawing.Size(249, 29);
            this.Clear_Everythings_btn.TabIndex = 43;
            this.Clear_Everythings_btn.Text = "Clear";
            this.Clear_Everythings_btn.Click += new System.EventHandler(this.Clear_Everythings_btn_Click);
            // 
            // Total_Result_label
            // 
            this.Transition1.SetDecoration(this.Total_Result_label, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Income_panel_Transition1.SetDecoration(this.Total_Result_label, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Total_Result_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Total_Result_label.ForeColor = System.Drawing.Color.DarkGray;
            this.Total_Result_label.Location = new System.Drawing.Point(77, 690);
            this.Total_Result_label.Name = "Total_Result_label";
            this.Total_Result_label.Size = new System.Drawing.Size(289, 23);
            this.Total_Result_label.TabIndex = 42;
            this.Total_Result_label.Text = "Total :";
            this.Total_Result_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Total_Result_label.Visible = false;
            // 
            // Total_Expenses
            // 
            this.Total_Expenses.AutoSize = true;
            this.Transition1.SetDecoration(this.Total_Expenses, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Income_panel_Transition1.SetDecoration(this.Total_Expenses, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Total_Expenses.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Total_Expenses.ForeColor = System.Drawing.Color.DarkGray;
            this.Total_Expenses.Location = new System.Drawing.Point(546, 622);
            this.Total_Expenses.Name = "Total_Expenses";
            this.Total_Expenses.Size = new System.Drawing.Size(0, 20);
            this.Total_Expenses.TabIndex = 41;
            this.Total_Expenses.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // T_REvenue_Label
            // 
            this.T_REvenue_Label.AutoSize = true;
            this.Transition1.SetDecoration(this.T_REvenue_Label, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Income_panel_Transition1.SetDecoration(this.T_REvenue_Label, Guna.UI2.AnimatorNS.DecorationType.None);
            this.T_REvenue_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.T_REvenue_Label.ForeColor = System.Drawing.Color.DarkGray;
            this.T_REvenue_Label.Location = new System.Drawing.Point(151, 625);
            this.T_REvenue_Label.Name = "T_REvenue_Label";
            this.T_REvenue_Label.Size = new System.Drawing.Size(0, 20);
            this.T_REvenue_Label.TabIndex = 40;
            this.T_REvenue_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Icome_TExp_label
            // 
            this.Transition1.SetDecoration(this.Icome_TExp_label, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Income_panel_Transition1.SetDecoration(this.Icome_TExp_label, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Icome_TExp_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icome_TExp_label.ForeColor = System.Drawing.Color.DarkGray;
            this.Icome_TExp_label.Location = new System.Drawing.Point(387, 622);
            this.Icome_TExp_label.Name = "Icome_TExp_label";
            this.Icome_TExp_label.Size = new System.Drawing.Size(139, 23);
            this.Icome_TExp_label.TabIndex = 40;
            this.Icome_TExp_label.Text = "Total Expenses :";
            this.Icome_TExp_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Icome_TExp_label.Visible = false;
            // 
            // Icome_TRev_label
            // 
            this.Transition1.SetDecoration(this.Icome_TRev_label, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Income_panel_Transition1.SetDecoration(this.Icome_TRev_label, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Icome_TRev_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icome_TRev_label.ForeColor = System.Drawing.Color.DarkGray;
            this.Icome_TRev_label.Location = new System.Drawing.Point(14, 622);
            this.Icome_TRev_label.Name = "Icome_TRev_label";
            this.Icome_TRev_label.Size = new System.Drawing.Size(150, 23);
            this.Icome_TRev_label.TabIndex = 39;
            this.Icome_TRev_label.Text = "Total Revenue:";
            this.Icome_TRev_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Icome_TRev_label.Visible = false;
            // 
            // Income_label
            // 
            this.Transition1.SetDecoration(this.Income_label, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Income_panel_Transition1.SetDecoration(this.Income_label, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Income_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Income_label.ForeColor = System.Drawing.Color.DimGray;
            this.Income_label.Location = new System.Drawing.Point(162, 579);
            this.Income_label.Name = "Income_label";
            this.Income_label.Size = new System.Drawing.Size(260, 31);
            this.Income_label.TabIndex = 38;
            this.Income_label.Text = "Income Report";
            this.Income_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Income_label.Visible = false;
            // 
            // GenerateIncome_btn
            // 
            this.GenerateIncome_btn.Animated = true;
            this.GenerateIncome_btn.AutoRoundedCorners = true;
            this.GenerateIncome_btn.BorderRadius = 13;
            this.GenerateIncome_btn.CheckedState.Parent = this.GenerateIncome_btn;
            this.GenerateIncome_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.GenerateIncome_btn.CustomImages.Parent = this.GenerateIncome_btn;
            this.Income_panel_Transition1.SetDecoration(this.GenerateIncome_btn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.GenerateIncome_btn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.GenerateIncome_btn.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GenerateIncome_btn.ForeColor = System.Drawing.Color.White;
            this.GenerateIncome_btn.HoverState.Parent = this.GenerateIncome_btn;
            this.GenerateIncome_btn.Location = new System.Drawing.Point(28, 533);
            this.GenerateIncome_btn.Name = "GenerateIncome_btn";
            this.GenerateIncome_btn.ShadowDecoration.Parent = this.GenerateIncome_btn;
            this.GenerateIncome_btn.Size = new System.Drawing.Size(249, 29);
            this.GenerateIncome_btn.TabIndex = 37;
            this.GenerateIncome_btn.Text = "Generate Icome ";
            this.GenerateIncome_btn.Click += new System.EventHandler(this.GenerateIncome_btn_Click);
            // 
            // guna2Separator2
            // 
            this.Income_panel_Transition1.SetDecoration(this.guna2Separator2, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.guna2Separator2, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2Separator2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.guna2Separator2.FillThickness = 2;
            this.guna2Separator2.Location = new System.Drawing.Point(-3, 566);
            this.guna2Separator2.Name = "guna2Separator2";
            this.guna2Separator2.Size = new System.Drawing.Size(611, 10);
            this.guna2Separator2.TabIndex = 36;
            this.guna2Separator2.UseTransparentBackground = true;
            // 
            // guna2Separator1
            // 
            this.Income_panel_Transition1.SetDecoration(this.guna2Separator1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.guna2Separator1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2Separator1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(252)))));
            this.guna2Separator1.FillThickness = 2;
            this.guna2Separator1.Location = new System.Drawing.Point(-3, 278);
            this.guna2Separator1.Name = "guna2Separator1";
            this.guna2Separator1.Size = new System.Drawing.Size(611, 10);
            this.guna2Separator1.TabIndex = 35;
            this.guna2Separator1.UseTransparentBackground = true;
            // 
            // Clear_ExpBox_btn
            // 
            this.Clear_ExpBox_btn.Animated = true;
            this.Clear_ExpBox_btn.AutoRoundedCorners = true;
            this.Clear_ExpBox_btn.BorderRadius = 13;
            this.Clear_ExpBox_btn.CheckedState.Parent = this.Clear_ExpBox_btn;
            this.Clear_ExpBox_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Clear_ExpBox_btn.CustomImages.Parent = this.Clear_ExpBox_btn;
            this.Income_panel_Transition1.SetDecoration(this.Clear_ExpBox_btn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.Clear_ExpBox_btn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Clear_ExpBox_btn.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Clear_ExpBox_btn.ForeColor = System.Drawing.Color.White;
            this.Clear_ExpBox_btn.HoverState.Parent = this.Clear_ExpBox_btn;
            this.Clear_ExpBox_btn.Location = new System.Drawing.Point(345, 480);
            this.Clear_ExpBox_btn.Name = "Clear_ExpBox_btn";
            this.Clear_ExpBox_btn.ShadowDecoration.Parent = this.Clear_ExpBox_btn;
            this.Clear_ExpBox_btn.Size = new System.Drawing.Size(146, 29);
            this.Clear_ExpBox_btn.TabIndex = 34;
            this.Clear_ExpBox_btn.Text = "Clear Expenses Box";
            this.Clear_ExpBox_btn.Click += new System.EventHandler(this.Clear_ExpBox_btn_Click);
            // 
            // label9
            // 
            this.Transition1.SetDecoration(this.label9, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Income_panel_Transition1.SetDecoration(this.label9, Guna.UI2.AnimatorNS.DecorationType.None);
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.DarkGray;
            this.label9.Location = new System.Drawing.Point(92, 401);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(169, 23);
            this.label9.TabIndex = 33;
            this.label9.Text = "Expenses Values..";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // EnterExpense_btn
            // 
            this.EnterExpense_btn.Animated = true;
            this.EnterExpense_btn.AutoRoundedCorners = true;
            this.EnterExpense_btn.BorderRadius = 13;
            this.EnterExpense_btn.CheckedState.Parent = this.EnterExpense_btn;
            this.EnterExpense_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.EnterExpense_btn.CustomImages.Parent = this.EnterExpense_btn;
            this.Income_panel_Transition1.SetDecoration(this.EnterExpense_btn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.EnterExpense_btn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.EnterExpense_btn.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.EnterExpense_btn.ForeColor = System.Drawing.Color.White;
            this.EnterExpense_btn.HoverState.Parent = this.EnterExpense_btn;
            this.EnterExpense_btn.Location = new System.Drawing.Point(342, 386);
            this.EnterExpense_btn.Name = "EnterExpense_btn";
            this.EnterExpense_btn.ShadowDecoration.Parent = this.EnterExpense_btn;
            this.EnterExpense_btn.Size = new System.Drawing.Size(149, 29);
            this.EnterExpense_btn.TabIndex = 32;
            this.EnterExpense_btn.Text = "Enter Expense";
            this.EnterExpense_btn.Click += new System.EventHandler(this.EnterExpense_btn_Click);
            // 
            // label10
            // 
            this.Transition1.SetDecoration(this.label10, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Income_panel_Transition1.SetDecoration(this.label10, Guna.UI2.AnimatorNS.DecorationType.None);
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.DarkGray;
            this.label10.Location = new System.Drawing.Point(92, 319);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(100, 23);
            this.label10.TabIndex = 31;
            this.label10.Text = "Expenses";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Expense_textBox
            // 
            this.Expense_textBox.Animated = true;
            this.Expense_textBox.AutoRoundedCorners = true;
            this.Expense_textBox.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(165)))));
            this.Expense_textBox.BorderRadius = 12;
            this.Expense_textBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Income_panel_Transition1.SetDecoration(this.Expense_textBox, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.Expense_textBox, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Expense_textBox.DefaultText = "";
            this.Expense_textBox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Expense_textBox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Expense_textBox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Expense_textBox.DisabledState.Parent = this.Expense_textBox;
            this.Expense_textBox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Expense_textBox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Expense_textBox.FocusedState.Parent = this.Expense_textBox;
            this.Expense_textBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Expense_textBox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Expense_textBox.HoverState.Parent = this.Expense_textBox;
            this.Expense_textBox.Location = new System.Drawing.Point(155, 345);
            this.Expense_textBox.Name = "Expense_textBox";
            this.Expense_textBox.PasswordChar = '\0';
            this.Expense_textBox.PlaceholderText = "Enter Expenses values...";
            this.Expense_textBox.SelectedText = "";
            this.Expense_textBox.ShadowDecoration.Parent = this.Expense_textBox;
            this.Expense_textBox.Size = new System.Drawing.Size(308, 26);
            this.Expense_textBox.TabIndex = 30;
            // 
            // Expense_Combobox
            // 
            this.Income_panel_Transition1.SetDecoration(this.Expense_Combobox, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.Expense_Combobox, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Expense_Combobox.FormattingEnabled = true;
            this.Expense_Combobox.Location = new System.Drawing.Point(155, 434);
            this.Expense_Combobox.Name = "Expense_Combobox";
            this.Expense_Combobox.Size = new System.Drawing.Size(308, 21);
            this.Expense_Combobox.TabIndex = 29;
            // 
            // ClearRevenue_btn
            // 
            this.ClearRevenue_btn.Animated = true;
            this.ClearRevenue_btn.AutoRoundedCorners = true;
            this.ClearRevenue_btn.BorderRadius = 13;
            this.ClearRevenue_btn.CheckedState.Parent = this.ClearRevenue_btn;
            this.ClearRevenue_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ClearRevenue_btn.CustomImages.Parent = this.ClearRevenue_btn;
            this.Income_panel_Transition1.SetDecoration(this.ClearRevenue_btn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.ClearRevenue_btn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.ClearRevenue_btn.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClearRevenue_btn.ForeColor = System.Drawing.Color.White;
            this.ClearRevenue_btn.HoverState.Parent = this.ClearRevenue_btn;
            this.ClearRevenue_btn.Location = new System.Drawing.Point(345, 230);
            this.ClearRevenue_btn.Name = "ClearRevenue_btn";
            this.ClearRevenue_btn.ShadowDecoration.Parent = this.ClearRevenue_btn;
            this.ClearRevenue_btn.Size = new System.Drawing.Size(146, 29);
            this.ClearRevenue_btn.TabIndex = 27;
            this.ClearRevenue_btn.Text = "Clear Revenue Box";
            this.ClearRevenue_btn.Click += new System.EventHandler(this.ClearRevenue_btn_Click);
            // 
            // label8
            // 
            this.Transition1.SetDecoration(this.label8, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Income_panel_Transition1.SetDecoration(this.label8, Guna.UI2.AnimatorNS.DecorationType.None);
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.DarkGray;
            this.label8.Location = new System.Drawing.Point(92, 151);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(169, 23);
            this.label8.TabIndex = 26;
            this.label8.Text = "Revenue Values..";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // EnterRevenue_btn
            // 
            this.EnterRevenue_btn.Animated = true;
            this.EnterRevenue_btn.AutoRoundedCorners = true;
            this.EnterRevenue_btn.BorderRadius = 13;
            this.EnterRevenue_btn.CheckedState.Parent = this.EnterRevenue_btn;
            this.EnterRevenue_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.EnterRevenue_btn.CustomImages.Parent = this.EnterRevenue_btn;
            this.Income_panel_Transition1.SetDecoration(this.EnterRevenue_btn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.EnterRevenue_btn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.EnterRevenue_btn.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EnterRevenue_btn.ForeColor = System.Drawing.Color.White;
            this.EnterRevenue_btn.HoverState.Parent = this.EnterRevenue_btn;
            this.EnterRevenue_btn.Location = new System.Drawing.Point(342, 136);
            this.EnterRevenue_btn.Name = "EnterRevenue_btn";
            this.EnterRevenue_btn.ShadowDecoration.Parent = this.EnterRevenue_btn;
            this.EnterRevenue_btn.Size = new System.Drawing.Size(149, 29);
            this.EnterRevenue_btn.TabIndex = 25;
            this.EnterRevenue_btn.Text = "Enter Revenue";
            this.EnterRevenue_btn.Click += new System.EventHandler(this.EnterRevenue_btn_Click);
            // 
            // label7
            // 
            this.Transition1.SetDecoration(this.label7, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Income_panel_Transition1.SetDecoration(this.label7, Guna.UI2.AnimatorNS.DecorationType.None);
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.DarkGray;
            this.label7.Location = new System.Drawing.Point(92, 69);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(100, 23);
            this.label7.TabIndex = 24;
            this.label7.Text = "Revenue";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Revenue_textBox
            // 
            this.Revenue_textBox.Animated = true;
            this.Revenue_textBox.AutoRoundedCorners = true;
            this.Revenue_textBox.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(77)))), ((int)(((byte)(165)))));
            this.Revenue_textBox.BorderRadius = 12;
            this.Revenue_textBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Income_panel_Transition1.SetDecoration(this.Revenue_textBox, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.Revenue_textBox, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Revenue_textBox.DefaultText = "";
            this.Revenue_textBox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Revenue_textBox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Revenue_textBox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Revenue_textBox.DisabledState.Parent = this.Revenue_textBox;
            this.Revenue_textBox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Revenue_textBox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Revenue_textBox.FocusedState.Parent = this.Revenue_textBox;
            this.Revenue_textBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Revenue_textBox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Revenue_textBox.HoverState.Parent = this.Revenue_textBox;
            this.Revenue_textBox.Location = new System.Drawing.Point(155, 95);
            this.Revenue_textBox.Name = "Revenue_textBox";
            this.Revenue_textBox.PasswordChar = '\0';
            this.Revenue_textBox.PlaceholderText = "Enter Revenue values...";
            this.Revenue_textBox.SelectedText = "";
            this.Revenue_textBox.ShadowDecoration.Parent = this.Revenue_textBox;
            this.Revenue_textBox.Size = new System.Drawing.Size(308, 26);
            this.Revenue_textBox.TabIndex = 23;
            // 
            // Revenue_Combobox
            // 
            this.Income_panel_Transition1.SetDecoration(this.Revenue_Combobox, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.Revenue_Combobox, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Revenue_Combobox.FormattingEnabled = true;
            this.Revenue_Combobox.Location = new System.Drawing.Point(155, 184);
            this.Revenue_Combobox.Name = "Revenue_Combobox";
            this.Revenue_Combobox.Size = new System.Drawing.Size(308, 21);
            this.Revenue_Combobox.TabIndex = 22;
            // 
            // label6
            // 
            this.Transition1.SetDecoration(this.label6, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Income_panel_Transition1.SetDecoration(this.label6, Guna.UI2.AnimatorNS.DecorationType.None);
            this.label6.Font = new System.Drawing.Font("Script MT Bold", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(117, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(374, 76);
            this.label6.TabIndex = 21;
            this.label6.Text = "Income Calculator";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.Transition1.SetDecoration(this.label5, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Income_panel_Transition1.SetDecoration(this.label5, Guna.UI2.AnimatorNS.DecorationType.None);
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.label5.Location = new System.Drawing.Point(55, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 20);
            this.label5.TabIndex = 19;
            // 
            // Intro_Panel
            // 
            this.Intro_Panel.BorderRadius = 50;
            this.Intro_Panel.Controls.Add(this.Web_panel);
            this.Intro_Panel.Controls.Add(this.label11);
            this.Income_panel_Transition1.SetDecoration(this.Intro_Panel, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.Intro_Panel, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Intro_Panel.FillColor = System.Drawing.Color.White;
            this.Intro_Panel.FillColor2 = System.Drawing.Color.White;
            this.Intro_Panel.Location = new System.Drawing.Point(271, 0);
            this.Intro_Panel.Name = "Intro_Panel";
            this.Intro_Panel.ShadowDecoration.Parent = this.Intro_Panel;
            this.Intro_Panel.Size = new System.Drawing.Size(614, 772);
            this.Intro_Panel.TabIndex = 44;
            // 
            // Web_panel
            // 
            this.Web_panel.Controls.Add(this.webBrowser1);
            this.Income_panel_Transition1.SetDecoration(this.Web_panel, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.Web_panel, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Web_panel.Location = new System.Drawing.Point(3, 85);
            this.Web_panel.Name = "Web_panel";
            this.Web_panel.Size = new System.Drawing.Size(605, 675);
            this.Web_panel.TabIndex = 7;
            // 
            // webBrowser1
            // 
            this.webBrowser1.AllowWebBrowserDrop = false;
            this.Income_panel_Transition1.SetDecoration(this.webBrowser1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this.webBrowser1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.webBrowser1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowser1.Location = new System.Drawing.Point(0, 0);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new System.Drawing.Size(605, 675);
            this.webBrowser1.TabIndex = 0;
            this.webBrowser1.Url = new System.Uri("https://www.youtube.com/watch?v=VYNTBWBqncU", System.UriKind.Absolute);
            // 
            // label11
            // 
            this.Transition1.SetDecoration(this.label11, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Income_panel_Transition1.SetDecoration(this.label11, Guna.UI2.AnimatorNS.DecorationType.None);
            this.label11.Font = new System.Drawing.Font("Script MT Bold", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.DimGray;
            this.label11.Location = new System.Drawing.Point(10, 12);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(550, 85);
            this.label11.TabIndex = 6;
            this.label11.Text = "Welcome to Calculations Section......";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Count_ItemRevenue_Notif
            // 
            this.Count_ItemRevenue_Notif.Alignment = Guna.UI2.WinForms.Enums.CustomContentAlignment.TopLeft;
            this.Count_ItemRevenue_Notif.TargetControl = this.EnterRevenue_btn;
            // 
            // Count_ItemExpenses_Notfi
            // 
            this.Count_ItemExpenses_Notfi.TargetControl = this.EnterExpense_btn;
            // 
            // Income_panel_Transition1
            // 
            this.Income_panel_Transition1.AnimationType = Guna.UI2.AnimatorNS.AnimationType.ScaleAndHorizSlide;
            this.Income_panel_Transition1.Cursor = null;
            animation1.AnimateOnlyDifferences = true;
            animation1.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.BlindCoeff")));
            animation1.LeafCoeff = 0F;
            animation1.MaxTime = 1F;
            animation1.MinTime = 0F;
            animation1.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.MosaicCoeff")));
            animation1.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation1.MosaicShift")));
            animation1.MosaicSize = 0;
            animation1.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            animation1.RotateCoeff = 0F;
            animation1.RotateLimit = 0F;
            animation1.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.ScaleCoeff")));
            animation1.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.SlideCoeff")));
            animation1.TimeCoeff = 0F;
            animation1.TransparencyCoeff = 0F;
            this.Income_panel_Transition1.DefaultAnimation = animation1;
            // 
            // Calculations
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1200, 772);
            this.Controls.Add(this.Intro_Panel);
            this.Controls.Add(this.Income_panel);
            this.Controls.Add(this.Calculator_Title_Label);
            this.Controls.Add(this.guna2Panel1);
            this.Controls.Add(this.Calculator_panel);
            this.Controls.Add(this.Design_panel);
            this.Income_panel_Transition1.SetDecoration(this, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Transition1.SetDecoration(this, Guna.UI2.AnimatorNS.DecorationType.None);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Calculations";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Calculations";
            this.Load += new System.EventHandler(this.Calculations_Load);
            this.Design_panel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox4)).EndInit();
            this.Calculator_panel.ResumeLayout(false);
            this.Calculator_panel.PerformLayout();
            this.guna2Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Back_btn)).EndInit();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).EndInit();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).EndInit();
            this.Advertise_1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            this.Income_panel.ResumeLayout(false);
            this.Income_panel.PerformLayout();
            this.Intro_Panel.ResumeLayout(false);
            this.Web_panel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2DragControl DragControl;
        private Guna.UI2.WinForms.Guna2Panel Design_panel;
        private Guna.UI2.WinForms.Guna2BorderlessForm BorderlessForm;
        private Guna.UI2.WinForms.Guna2Panel Calculator_panel;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton18;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton17;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton16;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton15;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton14;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton13;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton12;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton11;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton10;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton7;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton8;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton9;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton4;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton5;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton6;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton3;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton2;
        private Guna.UI2.WinForms.Guna2TextBox Result_TextBox;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton1;
        private System.Windows.Forms.Label Operator_label;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private System.Windows.Forms.GroupBox Advertise_1;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Guna.UI2.WinForms.Guna2Transition Transition1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox3;
        private System.Windows.Forms.Label Calculator_Title_Label;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox4;
        private System.Windows.Forms.Label label4;
        private Guna.UI2.WinForms.Guna2Button Calculator_Btn;
        private Guna.UI2.WinForms.Guna2Button Income_Btn;
        private Guna.UI2.WinForms.Guna2CircleButton EdgeDesign_Calculator;
        private Guna.UI2.WinForms.Guna2CircleButton Edge_Design_Income;
        private Guna.UI2.WinForms.Guna2PictureBox Back_btn;
        private System.Windows.Forms.ToolTip toolTip1;
        private Guna.UI2.WinForms.Guna2Panel Income_panel;
        private System.Windows.Forms.ComboBox Revenue_Combobox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private Guna.UI2.WinForms.Guna2TextBox Revenue_textBox;
        private System.Windows.Forms.Label label8;
        private Guna.UI2.WinForms.Guna2GradientButton EnterRevenue_btn;
        private Guna.UI2.WinForms.Guna2GradientButton ClearRevenue_btn;
        private Guna.UI2.WinForms.Guna2NotificationPaint Count_ItemRevenue_Notif;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator1;
        private Guna.UI2.WinForms.Guna2GradientButton Clear_ExpBox_btn;
        private System.Windows.Forms.Label label9;
        private Guna.UI2.WinForms.Guna2GradientButton EnterExpense_btn;
        private System.Windows.Forms.Label label10;
        private Guna.UI2.WinForms.Guna2TextBox Expense_textBox;
        private System.Windows.Forms.ComboBox Expense_Combobox;
        private Guna.UI2.WinForms.Guna2NotificationPaint Count_ItemExpenses_Notfi;
        private System.Windows.Forms.Label Total_Result_label;
        private System.Windows.Forms.Label Total_Expenses;
        private System.Windows.Forms.Label T_REvenue_Label;
        private System.Windows.Forms.Label Icome_TExp_label;
        private System.Windows.Forms.Label Icome_TRev_label;
        private System.Windows.Forms.Label Income_label;
        private Guna.UI2.WinForms.Guna2GradientButton GenerateIncome_btn;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator2;
        private Guna.UI2.WinForms.Guna2Transition Income_panel_Transition1;
        private Guna.UI2.WinForms.Guna2GradientButton Clear_Everythings_btn;
        private Guna.UI2.WinForms.Guna2GradientPanel Intro_Panel;
        private System.Windows.Forms.Panel Web_panel;
        private System.Windows.Forms.WebBrowser webBrowser1;
        private System.Windows.Forms.Label label11;
        private Guna.UI2.WinForms.Guna2Button Exp_btn;
    }
}